const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const db = require('./db');

const PORT = process.env.PORT || 3001;
const SITE_PATH = path.join(__dirname, 'okanagan.html');

// IndexNow key — proves domain ownership so Bing/Yandex/Seznam etc. accept
// instant-indexing submissions instead of waiting for a passive crawl.
// The key itself has no secrecy requirement (it's published at
// /{key}.txt by design, per the IndexNow protocol) — it just has to match
// between the hosted file and whatever key is sent with a submission.
const INDEXNOW_KEY = 'b25ba530bda42cb30e339b0dd848dadf';

// Phase 2.5B: a genuine shared-secret bearer token for the new enrichment
// endpoint below. This is deliberately NOT hardcoded — it's read from an
// environment variable that must be set on Railway (Variables tab) before
// the endpoint will accept any request at all. If the variable is unset,
// the endpoint fails closed (rejects everything) rather than falling back
// to any default or accepting unauthenticated requests. This is a
// different, unrelated value from INDEXNOW_KEY above, which is meant to be
// public — this one must be kept secret and never committed to source.
const ENRICHMENT_ADMIN_TOKEN = process.env.ENRICHMENT_ADMIN_TOKEN || null;


// ---------- helpers ----------

function sendJSON(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => (data += chunk));
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

// Constant-time comparison for the enrichment bearer token, so a caller
// can't learn anything about the correct token's contents by measuring
// response timing. If the lengths differ we return false immediately —
// a minor, widely-accepted length leak, not a content leak — rather than
// throwing (timingSafeEqual requires equal-length buffers).
function safeTokenEquals(provided, expected) {
  const a = Buffer.from(String(provided));
  const b = Buffer.from(String(expected));
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

const BOOL_FIELDS = [
  'dog_friendly', 'vegan', 'vegetarian', 'patio', 'kid_friendly',
  'gluten_free', 'lake_view', 'nonalcoholic', 'sports_tv', 'live_music',
  'great_groups', 'happy_hour',
];

const ALL_FIELDS = [
  'name', 'region', 'type', 'cuisine', 'phone', 'price', 'reviews', 'rating',
  'description', 'description_fr', 'hours', 'address', 'website', 'image_url',
  'latitude', 'longitude', ...BOOL_FIELDS,
];

function rowToVenue(row) {
  const v = { id: row.id, created_at: row.created_at, updated_at: row.updated_at };
  for (const f of ['name', 'region', 'type', 'cuisine', 'phone', 'price', 'reviews', 'rating', 'description', 'description_fr', 'hours', 'address', 'website', 'image_url', 'slug', 'latitude', 'longitude', 'redirect_to']) {
    v[f] = row[f];
  }
  for (const f of BOOL_FIELDS) {
    v[f] = !!row[f];
  }
  return v;
}

// ---------- route handlers ----------

// GET /api/venues  (supports ?region=&type=&dog_friendly=1&vegetarian=1&vegan=1&search=&min_rating=&page=&limit=)
function listVenues(query) {
  const clauses = ['redirect_to IS NULL'];
  const params = [];

  if (query.region) {
    clauses.push('region = ?');
    params.push(query.region);
  }
  if (query.type) {
    clauses.push('type = ?');
    params.push(query.type);
  }
  if (query.search) {
    clauses.push('(name LIKE ? OR description LIKE ? OR cuisine LIKE ?)');
    const like = `%${query.search}%`;
    params.push(like, like, like);
  }
  if (query.min_rating) {
    clauses.push('rating >= ?');
    params.push(parseFloat(query.min_rating));
  }
  for (const f of BOOL_FIELDS) {
    if (query[f] === '1' || query[f] === 'true') {
      clauses.push(`${f} = 1`);
    }
  }

  const where = clauses.length ? 'WHERE ' + clauses.join(' AND ') : '';

  const limit = Math.min(parseInt(query.limit) || 50, 2000);
  const page = Math.max(parseInt(query.page) || 1, 1);
  const offset = (page - 1) * limit;

  const countRow = db.prepare(`SELECT COUNT(*) AS n FROM venues ${where}`).get(...params);
  const rows = db
    .prepare(`SELECT * FROM venues ${where} ORDER BY name ASC LIMIT ? OFFSET ?`)
    .all(...params, limit, offset);

  return {
    total: countRow.n,
    page,
    limit,
    total_pages: Math.ceil(countRow.n / limit),
    venues: rows.map(rowToVenue),
  };
}

function getVenue(id) {
  const row = db.prepare('SELECT * FROM venues WHERE id = ?').get(id);
  return row ? rowToVenue(row) : null;
}

function createVenue(data) {
  if (!data.name || !data.region || !data.type) {
    const err = new Error('name, region, and type are required');
    err.status = 400;
    throw err;
  }
  const cols = ALL_FIELDS;
  const values = cols.map((f) => {
    if (BOOL_FIELDS.includes(f)) return data[f] ? 1 : 0;
    return data[f] !== undefined ? data[f] : null;
  });
  const placeholders = cols.map(() => '?').join(', ');
  const info = db
    .prepare(`INSERT INTO venues (${cols.join(', ')}) VALUES (${placeholders})`)
    .run(...values);
  return getVenue(info.lastInsertRowid);
}

function updateVenue(id, data) {
  const existing = db.prepare('SELECT * FROM venues WHERE id = ?').get(id);
  if (!existing) return null;

  const cols = ALL_FIELDS.filter((f) => data[f] !== undefined);
  if (cols.length === 0) return rowToVenue(existing);

  const setClause = cols.map((f) => `${f} = ?`).join(', ');
  const values = cols.map((f) => (BOOL_FIELDS.includes(f) ? (data[f] ? 1 : 0) : data[f]));

  db.prepare(`UPDATE venues SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(
    ...values,
    id
  );
  return getVenue(id);
}

// ---------- Phase 2.5: hardened, empty-field-only enrichment update ----------
//
// Purpose: a future enrichment process needs to write address/latitude/
// longitude ONLY when the existing value is genuinely empty, and must
// NEVER be able to overwrite an already-populated value — even under a
// stale-read race, where a process checked the value with a separate GET
// some time ago and is now writing based on that possibly-outdated belief.
//
// The critical design point: the "is this field empty" check and the
// actual write happen in the SAME SQL statement, evaluated atomically by
// SQLite at the moment the UPDATE runs — not as a separate check
// beforehand in application code. A stale application-level belief that a
// field was empty cannot cause an overwrite, because the database
// re-evaluates the WHERE clause against whatever the row's real, current
// state is right now, not whatever some earlier GET returned. This is
// what makes it safe against the exact race the phase asked to test:
// Process A's write, even if based on a stale read, will only actually
// change a row if that row is STILL empty at the instant the UPDATE runs.
//
// This function is intentionally NOT wired to any HTTP route in this
// phase — it exists as tested, available infrastructure for a future
// enrichment phase to call, per the "no new API routes" restriction here.
//
// Only address, latitude, and longitude are supported — deliberately
// narrow, matching the exact fields this hardening was requested for.
// Unknown fields are ignored rather than silently accepted.
const ENRICH_GUARDED_FIELDS = {
  address: {
    // Treat both NULL and empty-string as "empty", matching how the rest
    // of the app already treats an empty address.
    whereClause: `(address IS NULL OR address = '')`,
  },
  latitude: {
    whereClause: `latitude IS NULL`,
  },
  longitude: {
    whereClause: `longitude IS NULL`,
  },
};

// Attempts to write one or more of address/latitude/longitude for a
// venue, each independently guarded so a field already populated is left
// completely untouched. Returns a per-field result so the caller knows
// exactly which fields were actually written vs. skipped because they
// were already populated — this is important: a caller must never assume
// success just because the call didn't throw.
//
// data: { address?, latitude?, longitude? } — only keys present are
// considered; a key explicitly set to undefined is treated as "not
// requested" and left alone entirely.
function guardedEnrichUpdate(id, data) {
  const existing = db.prepare('SELECT * FROM venues WHERE id = ?').get(id);
  if (!existing) return { found: false, results: {} };

  const results = {};
  for (const field of Object.keys(ENRICH_GUARDED_FIELDS)) {
    if (data[field] === undefined) continue;
    const { whereClause } = ENRICH_GUARDED_FIELDS[field];
    // The empty-check and the write are the same atomic UPDATE statement.
    const info = db
      .prepare(`UPDATE venues SET ${field} = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND ${whereClause}`)
      .run(data[field], id);
    // info.changes === 1 means the row was still empty and got written.
    // info.changes === 0 means the row already had a value (or the id
    // didn't match, already excluded above) and was correctly left alone.
    results[field] = info.changes === 1 ? 'written' : 'skipped_not_empty';
  }
  return { found: true, results, venue: getVenue(id) };
}

// ---------- Phase 2.6R-support: authenticated correction of already-
// populated address/latitude/longitude, with mandatory expected-current
// verification and an audit trail. ----------
//
// This is deliberately a SEPARATE code path from guardedEnrichUpdate()
// above and does not alter its behavior in any way. Where the enrichment
// path guards against overwriting a POPULATED field, this path guards
// against overwriting a value that has DRIFTED from what the caller
// believes it currently is — the expected_current values must match the
// live row exactly, checked atomically in the same UPDATE statement,
// before any write happens.
//
// Only address, latitude, and longitude are supported, matching the
// enrichment path's narrow scope. Field names are hardcoded throughout
// (never taken from the request body), so arbitrary-column writes are
// not possible via this path either.
const CORRECT_GUARDED_FIELDS = ['address', 'latitude', 'longitude'];

// Returns one of:
//   { found: false }
//   { found: true, mismatch: true, live: {...} }               -- expected_current didn't match; nothing written
//   { found: true, mismatch: false, changedFields: [...], venue }  -- write succeeded (or no fields actually differed)
function guardedCorrectUpdate(id, expectedCurrent, corrected, meta) {
  const existing = db.prepare('SELECT * FROM venues WHERE id = ?').get(id);
  if (!existing) return { found: false };

  // Determine which fields actually differ between corrected and
  // expectedCurrent -- a field where corrected === expectedCurrent is not
  // a real change and does not need to be written or logged, but is not
  // an error either.
  const changedFields = CORRECT_GUARDED_FIELDS.filter(
    (f) => corrected[f] !== expectedCurrent[f]
  );

  if (changedFields.length === 0) {
    // Nothing to do -- expected_current and corrected are identical.
    return { found: true, mismatch: false, changedFields: [], venue: getVenue(id) };
  }

  // Build a single atomic UPDATE whose WHERE clause requires ALL THREE
  // expected_current values to match the row's CURRENT live state at the
  // instant the statement runs -- not a separate check beforehand. If the
  // row has drifted from what the caller expects (any of the three
  // fields), changes will be 0 and nothing is written, exactly mirroring
  // the atomicity guarantee guardedEnrichUpdate() already relies on.
  const setClause = CORRECT_GUARDED_FIELDS.map((f) => `${f} = ?`).join(', ');
  const setValues = CORRECT_GUARDED_FIELDS.map((f) => corrected[f]);

  let txOpen = false;
  try {
    db.exec('BEGIN');
    txOpen = true;

    const info = db
      .prepare(
        `UPDATE venues SET ${setClause}, updated_at = CURRENT_TIMESTAMP
         WHERE id = ? AND address = ? AND latitude = ? AND longitude = ?`
      )
      .run(...setValues, id, expectedCurrent.address, expectedCurrent.latitude, expectedCurrent.longitude);

    if (info.changes !== 1) {
      // Live row didn't match expected_current -- roll back (nothing was
      // actually written, but this keeps the transaction discipline
      // uniform) and report the mismatch along with the real live values
      // so the caller can see what actually changed underneath them.
      db.exec('ROLLBACK');
      txOpen = false;
      return { found: true, mismatch: true, live: getVenue(id) };
    }

    // Write one audit-log row per field that actually changed. If ANY of
    // these inserts fails, the whole transaction (including the venue
    // UPDATE above) is rolled back -- the correction must never be left
    // partially applied.
    const logStmt = db.prepare(
      `INSERT INTO venue_enrichment_log
         (venue_id, field_name, old_value, new_value, source, source_ref, confidence, batch_id, auto_accepted, reviewed_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`
    );
    for (const field of changedFields) {
      logStmt.run(
        id,
        field,
        String(expectedCurrent[field]),
        String(corrected[field]),
        'manual_correction',
        meta.reason,
        'high',
        meta.batch_id,
        meta.reviewed_by || null
      );
    }

    db.exec('COMMIT');
    txOpen = false;
    return { found: true, mismatch: false, changedFields, venue: getVenue(id) };
  } catch (err) {
    if (txOpen) {
      try {
        db.exec('ROLLBACK');
      } catch (_) {
        // ROLLBACK itself failing means there's nothing left to roll back
        // (e.g. the failure happened before BEGIN took effect) -- safe to
        // ignore, since the original error is what matters to the caller.
      }
    }
    throw err;
  }
}

// ---------- Phase 2.8D: duplicate-retirement (redirect_to) ----------
//
// Sets redirect_to on a duplicate venue, pointing at its canonical. This
// is a SEPARATE code path from both guardedEnrichUpdate() and
// guardedCorrectUpdate() above and does not alter either of their
// behavior in any way.
//
// This application's node:sqlite connection enforces foreign keys by
// default (verified: PRAGMA foreign_keys returns 1), so SQLite itself
// will reject a redirect_to value that doesn't match an existing
// venues.id. That guarantees the target ROW exists, but says nothing
// about self-redirects, chains, or the target already being a duplicate
// itself -- all of those are checked explicitly here, at the
// application layer, as the primary safeguard. FK enforcement is a
// welcome secondary backstop, not something this function relies on.
function guardedRetireUpdate(duplicateId, canonicalId) {
  // Self-redirect check.
  if (duplicateId === canonicalId) {
    return { ok: false, reason: 'self_redirect' };
  }

  const duplicate = db.prepare('SELECT * FROM venues WHERE id = ?').get(duplicateId);
  if (!duplicate) {
    return { ok: false, reason: 'duplicate_not_found' };
  }
  if (duplicate.redirect_to !== null && duplicate.redirect_to !== undefined) {
    return { ok: false, reason: 'duplicate_already_redirected', current_redirect_to: duplicate.redirect_to };
  }

  const canonical = db.prepare('SELECT * FROM venues WHERE id = ?').get(canonicalId);
  if (!canonical) {
    return { ok: false, reason: 'canonical_not_found' };
  }
  // Refuse if the canonical is itself already a duplicate of something
  // else -- writing this would create a two-hop chain.
  if (canonical.redirect_to !== null && canonical.redirect_to !== undefined) {
    return { ok: false, reason: 'canonical_is_itself_a_duplicate', canonical_redirect_to: canonical.redirect_to };
  }
  // Refuse if any OTHER existing duplicate already points at this same
  // duplicateId as ITS canonical -- i.e. duplicateId is itself someone
  // else's canonical target. Retiring it would orphan that other
  // duplicate's redirect into a chain.
  const dependents = db.prepare('SELECT id FROM venues WHERE redirect_to = ?').all(duplicateId);
  if (dependents.length > 0) {
    return { ok: false, reason: 'duplicate_is_a_canonical_for_others', dependents: dependents.map((d) => d.id) };
  }

  let txOpen = false;
  try {
    db.exec('BEGIN');
    txOpen = true;
    const info = db
      .prepare('UPDATE venues SET redirect_to = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND redirect_to IS NULL')
      .run(canonicalId, duplicateId);
    if (info.changes !== 1) {
      db.exec('ROLLBACK');
      txOpen = false;
      return { ok: false, reason: 'precondition_changed_mid_write' };
    }
    db.exec('COMMIT');
    txOpen = false;
    return { ok: true, venue: getVenue(duplicateId) };
  } catch (err) {
    if (txOpen) {
      try {
        db.exec('ROLLBACK');
      } catch (_) {}
    }
    throw err;
  }
}

// ---------- Phase 2.8G: guarded single-field region correction ----------
//
// A SEPARATE, standalone code path. Does not touch guardedEnrichUpdate(),
// guardedCorrectUpdate(), guardedRetireUpdate(), or
// guardedMergeAndRetireUpdate() in any way, and is not reachable through
// any of their routes.
//
// Deliberately NOT built by extending guardedCorrectUpdate()'s
// CORRECT_GUARDED_FIELDS, so that this new capability's blast radius stays
// scoped to exactly one column rather than widening an existing
// multi-field mechanism.
//
// The SQL below has NO dynamic column construction anywhere -- "region" is
// a literal in the SET clause, never a variable. The only two values ever
// bound as parameters are the corrected region value and the
// expected-current region value; a column NAME is never accepted from the
// caller in this function at all.
const VALID_REGIONS = [
  'kelowna', 'penticton', 'vernon', 'west-kelowna', 'oliver', 'osoyoos',
  'summerland', 'naramata', 'lake-country', 'okanagan-falls', 'big-white',
  'peachland', 'armstrong', 'silverstar', 'enderby', 'coldstream', 'lumby',
  'apex', 'kaleden', 'baldy',
];

function guardedRegionCorrectUpdate(id, expectedCurrentRegion, correctedRegion) {
  if (!VALID_REGIONS.includes(correctedRegion)) {
    return { ok: false, reason: 'invalid_region_value' };
  }

  const existing = db.prepare('SELECT * FROM venues WHERE id = ?').get(id);
  if (!existing) {
    return { ok: false, reason: 'venue_not_found' };
  }

  if (existing.region === correctedRegion) {
    // Already correct -- nothing to do. Not an error, but no write either.
    return { ok: true, noop: true, venue: getVenue(id) };
  }

  const info = db
    .prepare('UPDATE venues SET region = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND region = ?')
    .run(correctedRegion, id, expectedCurrentRegion);

  if (info.changes === 0) {
    return { ok: false, reason: 'precondition_failed_region_mismatch', live_region: existing.region };
  }
  if (info.changes > 1) {
    // Structurally should be impossible (id is the primary key), but
    // treat defensively as a hard failure rather than assume success.
    return { ok: false, reason: 'unexpected_multi_row_match', changes: info.changes };
  }

  return { ok: true, noop: false, venue: getVenue(id) };
}

function deleteVenue(id) {
  const info = db.prepare('DELETE FROM venues WHERE id = ?').run(id);

  return info.changes > 0;
}

// ---------- Phase 2.8E/2.8F: narrow field-merge + retire ----------
//
// A SEPARATE, additional code path from guardedRetireUpdate() above -- that
// function is completely unmodified and unaffected by this one. This one is
// scoped specifically to the case where a duplicate carries a small,
// explicit set of null-vs-value fields that should be transferred to the
// canonical BEFORE/WITH the redirect, rather than lost.
//
// MERGEABLE_FIELDS is a hardcoded master allowlist. Field NAMES are NEVER
// taken from the request body -- only VALUES are, and only for keys that
// already appear in this hardcoded array. This makes arbitrary-column
// writes structurally impossible via this endpoint, matching the existing
// guardedEnrichUpdate()/guardedCorrectUpdate()/guardedRetireUpdate()
// pattern.
//
// Phase 2.8F extends this from "always require exactly phone+price+reviews"
// to "accept any non-empty SUBSET of this master list", so a single pair
// can be authorized to transfer just e.g. description_fr, without widening
// what field names are reachable at all. The set of fields actually
// touched by the SQL statement is built from Object.keys(fieldValues)
// filtered against MERGEABLE_FIELDS -- never from arbitrary request input.
const MERGEABLE_FIELDS = ['phone', 'price', 'reviews', 'description_fr'];

function guardedMergeAndRetireUpdate(duplicateId, canonicalId, fieldValues) {
  // Self-redirect check.
  if (duplicateId === canonicalId) {
    return { ok: false, reason: 'self_redirect' };
  }

  // Validate fieldValues keys are a NON-EMPTY SUBSET of the master
  // allowlist. Reject anything unexpected rather than silently ignoring
  // it. Reject an empty payload (a merge call must actually merge
  // something, or callers should use plain /admin/retire-duplicate
  // instead).
  const providedKeys = Object.keys(fieldValues);
  if (providedKeys.length === 0) {
    return { ok: false, reason: 'no_merge_fields_provided' };
  }
  const unexpectedKeys = providedKeys.filter((k) => !MERGEABLE_FIELDS.includes(k));
  if (unexpectedKeys.length > 0) {
    return { ok: false, reason: 'unexpected_merge_fields', unexpectedKeys };
  }
  // De-duplicate and fix the exact field order deterministically (the
  // order of MERGEABLE_FIELDS, not the order keys happened to arrive in
  // the request), so the generated SQL is always identical for a given
  // field set regardless of client-supplied key ordering.
  const fieldsToMerge = MERGEABLE_FIELDS.filter((f) => providedKeys.includes(f));

  const duplicate = db.prepare('SELECT * FROM venues WHERE id = ?').get(duplicateId);
  if (!duplicate) {
    return { ok: false, reason: 'duplicate_not_found' };
  }
  if (duplicate.redirect_to !== null && duplicate.redirect_to !== undefined) {
    return { ok: false, reason: 'duplicate_already_redirected', current_redirect_to: duplicate.redirect_to };
  }

  const canonical = db.prepare('SELECT * FROM venues WHERE id = ?').get(canonicalId);
  if (!canonical) {
    return { ok: false, reason: 'canonical_not_found' };
  }
  if (canonical.redirect_to !== null && canonical.redirect_to !== undefined) {
    return { ok: false, reason: 'canonical_is_itself_a_duplicate', canonical_redirect_to: canonical.redirect_to };
  }
  const dependents = db.prepare('SELECT id FROM venues WHERE redirect_to = ?').all(duplicateId);
  if (dependents.length > 0) {
    return { ok: false, reason: 'duplicate_is_a_canonical_for_others', dependents: dependents.map((d) => d.id) };
  }

  // Precondition: every field being merged IN THIS CALL must currently be
  // NULL on the canonical -- not the full master list, just whatever
  // subset this call specified. Checked here for a clear error message,
  // AND enforced again atomically inside the UPDATE's WHERE clause below.
  const nonNullOnCanonical = fieldsToMerge.filter(
    (f) => canonical[f] !== null && canonical[f] !== undefined
  );
  if (nonNullOnCanonical.length > 0) {
    return { ok: false, reason: 'canonical_field_not_null', fields: nonNullOnCanonical };
  }

  let txOpen = false;
  try {
    db.exec('BEGIN');
    txOpen = true;

    // Statement 1: merge only the requested (validated, allowlisted)
    // fields onto the canonical. Column names come only from
    // fieldsToMerge, which is itself filtered from MERGEABLE_FIELDS --
    // never from raw request keys. Guarded by requiring every one of
    // those specific fields to still be NULL at write time.
    const setClause = fieldsToMerge.map((f) => `${f} = ?`).join(', ');
    const whereNullClause = fieldsToMerge.map((f) => `${f} IS NULL`).join(' AND ');
    const setValues = fieldsToMerge.map((f) => fieldValues[f]);

    const mergeInfo = db
      .prepare(
        `UPDATE venues SET ${setClause}, updated_at = CURRENT_TIMESTAMP ` +
          `WHERE id = ? AND ${whereNullClause}`
      )
      .run(...setValues, canonicalId);

    if (mergeInfo.changes !== 1) {
      db.exec('ROLLBACK');
      txOpen = false;
      return { ok: false, reason: 'canonical_precondition_changed_mid_write' };
    }

    // Statement 2: the redirect, identical guard to guardedRetireUpdate().
    const redirectInfo = db
      .prepare('UPDATE venues SET redirect_to = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND redirect_to IS NULL')
      .run(canonicalId, duplicateId);

    if (redirectInfo.changes !== 1) {
      db.exec('ROLLBACK');
      txOpen = false;
      return { ok: false, reason: 'duplicate_precondition_changed_mid_write' };
    }

    db.exec('COMMIT');
    txOpen = false;
    return { ok: true, canonical: getVenue(canonicalId), duplicate: getVenue(duplicateId), mergedFields: fieldsToMerge };
  } catch (err) {
    if (txOpen) {
      try {
        db.exec('ROLLBACK');
      } catch (_) {}

    }
    throw err;
  }
}

function getStats() {
  const total = db.prepare('SELECT COUNT(*) AS n FROM venues WHERE redirect_to IS NULL').get().n;
  const phoned = db.prepare("SELECT COUNT(*) AS n FROM venues WHERE phone IS NOT NULL AND phone != '' AND redirect_to IS NULL").get().n;
  const vegetarian = db.prepare('SELECT COUNT(*) AS n FROM venues WHERE vegetarian = 1 AND redirect_to IS NULL').get().n;
  const vegan = db.prepare('SELECT COUNT(*) AS n FROM venues WHERE vegan = 1 AND redirect_to IS NULL').get().n;
  const byRegion = db.prepare('SELECT region, COUNT(*) AS n FROM venues GROUP BY region ORDER BY n DESC').all();
  const byType = db.prepare('SELECT type, COUNT(*) AS n FROM venues GROUP BY type ORDER BY n DESC').all();
  return { total, phoned, vegetarian, vegan, by_region: byRegion, by_type: byType };
}

// ---------- SEO guide pages ----------
//
// The main site is a single-page app, so before this feature the only
// crawlable URL on the whole domain was "/". That meant none of the site's
// badge data (dog-friendly, patio, happy hour, etc.) could ever surface in
// search results, get shared as a link with a real preview, or rank for
// long-tail searches like "dog friendly wineries kelowna".
//
// This adds one real, server-rendered, indexable page per region+badge
// combination that has enough venues to be genuinely useful:
// GET /guide/:region/:badge  ->  e.g. /guide/kelowna/dog_friendly
//
// Each page is plain server-rendered HTML (no JS required to see content),
// has its own <title>/meta description/canonical/OG tags, and lists the
// real matching venues with their real descriptions. It links back to the
// main app so visitors can explore further. A MIN_GUIDE_VENUES threshold
// keeps thin/near-empty pages out of the sitemap.

const MIN_GUIDE_VENUES = 8;

const REGION_LABELS = {
  kelowna: 'Kelowna', 'west-kelowna': 'West Kelowna', peachland: 'Peachland',
  summerland: 'Summerland', penticton: 'Penticton', naramata: 'Naramata',
  'lake-country': 'Lake Country', 'okanagan-falls': 'Okanagan Falls',
  oliver: 'Oliver', osoyoos: 'Osoyoos', vernon: 'Vernon', armstrong: 'Armstrong',
  coldstream: 'Coldstream', lumby: 'Lumby', enderby: 'Enderby', kaleden: 'Kaleden',
  apex: 'Apex', 'big-white': 'Big White', silverstar: 'SilverStar', baldy: 'Baldy',
};

const BADGE_LABELS = {
  dog_friendly: { title: 'Dog-Friendly', noun: 'dog-friendly spots', adj: 'dog-friendly' },
  vegan: { title: 'Vegan-Friendly', noun: 'vegan-friendly venues', adj: 'vegan-friendly' },
  vegetarian: { title: 'Vegetarian-Friendly', noun: 'vegetarian-friendly venues', adj: 'vegetarian-friendly' },
  patio: { title: 'Patio', noun: 'venues with a patio', adj: 'patio' },
  kid_friendly: { title: 'Kid-Friendly', noun: 'kid-friendly spots', adj: 'kid-friendly' },
  gluten_free: { title: 'Gluten-Free-Friendly', noun: 'venues with gluten-free options', adj: 'gluten-free-friendly' },
  lake_view: { title: 'Lake View', noun: 'venues with a lake view', adj: 'lake-view' },
  nonalcoholic: { title: 'Non-Alcoholic Options', noun: 'venues with non-alcoholic options', adj: 'non-alcoholic-friendly' },
  sports_tv: { title: 'Sports TV', noun: 'spots to watch the game', adj: 'sports-viewing' },
  live_music: { title: 'Live Music', noun: 'venues with live music', adj: 'live-music' },
  great_groups: { title: 'Great for Groups', noun: 'venues that are great for groups', adj: 'group-friendly' },
  happy_hour: { title: 'Happy Hour', noun: 'venues with happy hour', adj: 'happy-hour' },
};

// ---------- SEO architecture: regions / categories / venue pages ----------
// Phase 2 of the SEO roadmap: /:region, /:region/:category, and
// /:region/:category/:venueSlug, sitting alongside the existing /guide
// pages (untouched) and the existing SPA (untouched).

const MIN_CATEGORY_VENUES = 1; // a region/category page renders as soon as at least one real venue exists in it

// DB `type` -> URL category slug (also doubles as the reverse lookup below)
const CATEGORY_SLUGS = {
  restaurant: 'restaurants',
  winery: 'wineries',
  cafe: 'cafes',
  brewery: 'breweries',
  pub: 'pubs',
  cocktail: 'cocktail-lounges',
};
const SLUG_TO_TYPE = Object.fromEntries(Object.entries(CATEGORY_SLUGS).map(([type, slug]) => [slug, type]));

// Human-readable label per category, singular and plural, for titles/H1s
const CATEGORY_LABELS = {
  restaurant: { singular: 'Restaurant', plural: 'Restaurants' },
  winery: { singular: 'Winery', plural: 'Wineries' },
  cafe: { singular: 'Cafe', plural: 'Cafes' },
  brewery: { singular: 'Brewery', plural: 'Breweries' },
  pub: { singular: 'Pub', plural: 'Pubs' },
  cocktail: { singular: 'Cocktail Lounge', plural: 'Cocktail Lounges' },
};

// DB `type` -> schema.org @type. Every one of these is a real, valid
// schema.org type under LocalBusiness > FoodEstablishment — no generic
// fallback needed for the 6 types this site currently has.
const SCHEMA_TYPE_MAP = {
  restaurant: 'Restaurant',
  winery: 'Winery',
  cafe: 'CafeOrCoffeeShop',
  brewery: 'Brewery',
  pub: 'BarOrPub',
  cocktail: 'BarOrPub', // schema.org has no distinct "cocktail lounge" type; BarOrPub is the correct closest official type
};

function slugify(name) {
  return String(name)
    .toLowerCase()
    .normalize('NFKD').replace(/[\u0300-\u036f]/g, '') // strip accents
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

// One-time, idempotent backfill: assigns a permanent slug to any venue
// that doesn't have one yet. Never touches a venue that already has a
// slug — per the "permanent stored slugs" decision, slugs are not
// regenerated if a name changes later. Collisions (same region+type+slug)
// are resolved deterministically by appending the venue's own id, so the
// result is stable and reproducible even if this runs again.
// One-time, idempotent backfill: assigns a permanent slug to any venue
// that doesn't have one yet. Never touches a venue that already has a
// slug — per the "permanent stored slugs" decision, slugs are not
// regenerated if a name changes later.
//
// Collision resolution is a deterministic loop: base -> base-{id} ->
// base-{id}-2 -> base-{id}-3 -> ... Each candidate is checked against
// BOTH the in-memory set built for this run AND the database directly
// (the database is the final authority — the in-memory set is a fast
// pre-check, not a substitute for asking the actual table). This
// protects against any second-order collision where a disambiguated
// candidate (e.g. "foo-25") coincidentally matches another venue's own
// independently-generated slug.
//
// Returns { count, errors } and NEVER throws — if a specific row
// genuinely cannot be given a unique slug (should be structurally
// impossible, since the loop can extend indefinitely), that row's id,
// name, region, and type are recorded in `errors` and processing
// continues with the next venue rather than aborting the whole batch or
// silently pretending success.
function backfillSlugs() {
  const rows = db.prepare('SELECT id, name, region, type FROM venues WHERE slug IS NULL ORDER BY id').all();
  if (rows.length === 0) return { count: 0, errors: [] };

  const usedInScope = new Set(
    db.prepare('SELECT region, type, slug FROM venues WHERE slug IS NOT NULL').all()
      .map((r) => `${r.region}|${r.type}|${r.slug}`)
  );

  const existsInDb = db.prepare(
    'SELECT 1 FROM venues WHERE region = ? AND type = ? AND slug = ? LIMIT 1'
  );
  const updateSlug = db.prepare('UPDATE venues SET slug = ? WHERE id = ?');

  const MAX_ATTEMPTS = 1000; // structurally should never be reached; a safety bound, not a real expectation
  let count = 0;
  const errors = [];

  for (const row of rows) {
    // Defensive fallback for empty/unusual names (e.g. "", "   ", "!!!")
    // that would otherwise slugify to an empty string.
    const base = slugify(row.name) || `venue-${row.id}`;

    let attempt = 0;
    let candidate = base;
    let scopeKey = `${row.region}|${row.type}|${candidate}`;

    while (
      usedInScope.has(scopeKey) ||
      existsInDb.get(row.region, row.type, candidate)
    ) {
      attempt++;
      if (attempt > MAX_ATTEMPTS) {
        errors.push({
          id: row.id,
          name: row.name,
          region: row.region,
          type: row.type,
          reason: `could not find a unique slug after ${MAX_ATTEMPTS} attempts`,
        });
        candidate = null;
        break;
      }
      candidate = attempt === 1 ? `${base}-${row.id}` : `${base}-${row.id}-${attempt}`;
      scopeKey = `${row.region}|${row.type}|${candidate}`;
    }

    if (candidate === null) continue; // recorded in errors above; do not update, do not fake success

    usedInScope.add(scopeKey);
    try {
      updateSlug.run(candidate, row.id);
      count++;
    } catch (err) {
      // The database is the final authority: if it still rejects this
      // candidate for any reason (should be unreachable given the checks
      // above), record exactly which venue failed rather than crash or
      // silently skip.
      errors.push({ id: row.id, name: row.name, region: row.region, type: row.type, reason: err.message });
    }
  }

  return { count, errors };
}

function getRegionCategoryCounts(region) {
  // { restaurant: 12, winery: 4, ... } for a region, only categories with >=1 venue
  return db
    .prepare('SELECT type, COUNT(*) AS n FROM venues WHERE region = ? GROUP BY type')
    .all(region)
    .filter((r) => CATEGORY_SLUGS[r.type]) // ignore any unexpected/unmapped type defensively
    .reduce((acc, r) => { acc[r.type] = r.n; return acc; }, {});
}

function getVenuesByRegionCategory(region, type) {
  return db
    .prepare('SELECT * FROM venues WHERE region = ? AND type = ? AND redirect_to IS NULL ORDER BY name ASC')
    .all(region, type)
    .map(rowToVenue);
}

function findVenueBySlug(region, type, slug) {
  const row = db
    .prepare('SELECT * FROM venues WHERE region = ? AND type = ? AND slug = ?')
    .get(region, type, slug);
  return row ? rowToVenue(row) : null;
}

function getRelatedVenues(venue, limit = 6) {
  // Same region + same category, excluding itself
  return db
    .prepare('SELECT * FROM venues WHERE region = ? AND type = ? AND id != ? AND redirect_to IS NULL ORDER BY rating DESC, name ASC LIMIT ?')
    .all(venue.region, venue.type, venue.id, limit)
    .map(rowToVenue);
}

function getNearbyVenues(venue, limit = 6) {
  // Same region, any other category, excluding itself — a broader
  // "explore this region more" set distinct from same-category related venues
  return db
    .prepare('SELECT * FROM venues WHERE region = ? AND type != ? AND id != ? AND redirect_to IS NULL ORDER BY rating DESC, name ASC LIMIT ?')
    .all(venue.region, venue.type, venue.id, limit)
    .map(rowToVenue);
}

function breadcrumbListSchema(items) {
  // items: [{ name, url }, ...] in order from Home to the current page
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  };
}

// Phase 2.1: builds schema.org OpeningHoursSpecification entries from the
// EXISTING venues.hours column only. Reads real stored data, generates
// nothing, invents nothing, calls nothing external.
//
// Expected shape of the parsed hours JSON (already in production use by
// the visible "Hours" section on venue pages):
//   { mon: [["09:00","17:00"]], tue: [], wed: null, ... , sun: [...] }
// - A day mapped to a non-empty array means one OpeningHoursSpecification
//   per [start, end] pair in that array (this is how split shifts, e.g.
//   lunch + dinner, are already represented).
// - A day mapped to null, an empty array, or simply absent all mean the
//   same thing: no opening period is generated for that day. This matches
//   how the existing HTML "Hours" rendering already treats these three
//   cases identically as "Closed".
// - Any per-day or per-range value that isn't in the expected shape is
//   skipped individually rather than aborting the whole venue, so one bad
//   entry can't take down the others or crash rendering.
// Returns undefined (not an empty array) when there's nothing valid to
// show, so the property is cleanly omitted from the schema object exactly
// like every other conditional field already in localBusiness.
const DAY_SCHEMA_NAMES = {
  mon: 'https://schema.org/Monday',
  tue: 'https://schema.org/Tuesday',
  wed: 'https://schema.org/Wednesday',
  thu: 'https://schema.org/Thursday',
  fri: 'https://schema.org/Friday',
  sat: 'https://schema.org/Saturday',
  sun: 'https://schema.org/Sunday',
};
const DAY_ORDER = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
const VALID_TIME = /^([01]?\d|2[0-3]):([0-5]\d)$/; // accepts "9:00" and "09:00" alike; output is always zero-padded

function normalizeTime(t) {
  const m = VALID_TIME.exec(t);
  if (!m) return null;
  return `${m[1].padStart(2, '0')}:${m[2]}`;
}

function buildOpeningHoursSpecification(hoursRaw) {
  if (!hoursRaw) return undefined;

  let hoursObj;
  try {
    hoursObj = JSON.parse(hoursRaw);
  } catch (e) {
    return undefined; // malformed JSON — omit rather than guess
  }
  if (!hoursObj || typeof hoursObj !== 'object') return undefined;

  const specs = [];
  for (const day of DAY_ORDER) {
    const ranges = hoursObj[day];
    if (!Array.isArray(ranges)) continue; // null, missing, or wrong type -> treated as closed, same as existing HTML rendering
    for (const range of ranges) {
      if (!Array.isArray(range) || range.length !== 2) continue; // malformed single entry -> skip just this one
      const opens = normalizeTime(range[0]);
      const closes = normalizeTime(range[1]);
      if (!opens || !closes) continue; // malformed time -> skip just this one
      specs.push({
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: DAY_SCHEMA_NAMES[day],
        opens,
        closes,
      });
    }
  }

  return specs.length > 0 ? specs : undefined;
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function listGuideCombos(minCount) {
  // One row per region+badge combo that clears the venue-count threshold,
  // computed live from the DB so the guide/sitemap list grows automatically
  // as more venues get badges — no hardcoded list to fall out of date.
  const combos = [];
  for (const region of Object.keys(REGION_LABELS)) {
    for (const badge of BOOL_FIELDS) {
      const row = db
        .prepare(`SELECT COUNT(*) AS n FROM venues WHERE region = ? AND ${badge} = 1 AND redirect_to IS NULL`)
        .get(region);
      if (row.n >= minCount) combos.push({ region, badge, count: row.n });
    }
  }
  return combos;
}

function renderGuidePage(region, badge, venues) {
  const regionLabel = REGION_LABELS[region];
  const badgeInfo = BADGE_LABELS[badge];
  const title = `${badgeInfo.title} Venues in ${regionLabel}, BC | Okanagan Roam`;
  const description = `${venues.length} verified ${badgeInfo.noun} in ${regionLabel}, BC — wineries, restaurants, breweries, and more, reviewed and badge-checked by Okanagan Roam.`;
  const canonical = `https://okanaganroam.com/guide/${region}/${badge}`;
  const regionUrl = `https://okanaganroam.com/${region}`;

  const breadcrumb = breadcrumbListSchema([
    { name: 'Home', url: 'https://okanaganroam.com/' },
    { name: regionLabel, url: regionUrl },
    { name: `${badgeInfo.title} Venues`, url: canonical },
  ]);

  // Cross-link to whichever category pages actually have venues on this
  // guide page — e.g. a "Kelowna Dog-Friendly" page that lists both
  // restaurants and wineries links to both /kelowna/restaurants and
  // /kelowna/wineries, not just one.
  const categoriesPresent = [...new Set(venues.map((v) => v.type))]
    .filter((t) => CATEGORY_SLUGS[t])
    .sort();
  const categoryLinksHtml = categoriesPresent.length
    ? `<p class="venue-meta">Browse by category: ${categoriesPresent
        .map((t) => `<a href="/${region}/${CATEGORY_SLUGS[t]}">${escapeHtml(CATEGORY_LABELS[t].plural)}</a>`)
        .join(', ')}</p>`
    : '';

  const cards = venues.map((v) => venueCardHtml(v, { showType: true })).join('\n');

  const itemList = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: title,
    description,
    // No cap — every venue on the visible page is also in the structured
    // data, however large the list gets.
    itemListElement: venues.map((v, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      url: (v.slug && CATEGORY_SLUGS[v.type]) ? `https://okanaganroam.com/${v.region}/${CATEGORY_SLUGS[v.type]}/${v.slug}` : undefined,
      item: {
        '@type': SCHEMA_TYPE_MAP[v.type] || 'LocalBusiness',
        name: v.name,
        description: v.description || undefined,
      },
    })),
  };

  return `<!DOCTYPE html>
<html lang="en">
<head>
${pageHead(title, description, canonical, [breadcrumb, itemList])}
</head>
<body>
  ${siteHeader('https://okanaganroam.com/', 'Explore the full directory \u2192')}
  ${breadcrumbNavHtml([
    { name: 'Home', href: '/' },
    { name: regionLabel, href: `/${region}` },
    { name: `${badgeInfo.title} Venues` },
  ])}
  <h1>${escapeHtml(badgeInfo.title)} Venues in ${escapeHtml(regionLabel)}, BC</h1>
  <p class="subtitle">${venues.length} verified ${escapeHtml(badgeInfo.noun)} in ${escapeHtml(regionLabel)} — badge-checked from real listings, not guessed.</p>
  ${categoryLinksHtml}
  <ul class="card-grid">
    ${cards}
  </ul>
  <a class="cta" href="/${region}">See all of ${escapeHtml(regionLabel)} on Okanagan Roam</a>
  ${siteFooter()}
</body>
</html>`;
}

function renderGuideFooterHTML() {
  const combos = listGuideCombos(MIN_GUIDE_VENUES);
  if (combos.length === 0) return '';

  const byRegion = {};
  for (const c of combos) {
    (byRegion[c.region] = byRegion[c.region] || []).push(c);
  }

  const sections = Object.keys(byRegion)
    .sort((a, b) => byRegion[b].length - byRegion[a].length)
    .map((region) => {
      const links = byRegion[region]
        .sort((a, b) => b.count - a.count)
        .map(
          (c) =>
            `<a href="/guide/${c.region}/${c.badge}">${escapeHtml(BADGE_LABELS[c.badge].title)} (${c.count})</a>`
        )
        .join(', ');
      return `<div class="og-guide-region"><strong><a href="/${region}">${escapeHtml(REGION_LABELS[region])}</a>:</strong> ${links}</div>`;
    })
    .join('\n');

  return `
<footer id="og-guides" style="max-width:960px;margin:40px auto;padding:24px 20px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:13px;line-height:1.8;color:#52606d;border-top:1px solid #e4e7eb;">
  <p style="margin:0 0 10px;font-weight:600;color:#1f2933;">Browse Okanagan Roam by guide</p>
  ${sections}
</footer>`;
}

// ---------- shared SEO page CSS (region / category / venue pages) ----------
// One shared style block so these three page types look and feel
// consistent, and so it's defined once rather than duplicated three times.
// Phase 5 Sprint 1: recolored to reference the shared design tokens
// (loaded via the <link rel="stylesheet" href="/styles/tokens.css"> that
// pageHead() now emits) instead of this block's own, previously
// disconnected hardcoded palette. Layout/structure is unchanged — this is
// the "single source of truth for styling" step; the full Sprint 2 visual
// redesign of these templates is separate, later work.
const SEO_PAGE_CSS = `
  :root { color-scheme: light; }
  body { font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 860px; margin: 0 auto; padding: 24px 20px 64px; color: var(--ink); background: var(--paper); line-height: 1.5; }
  a { color: var(--teal); }
  header.top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
  header.top a.brand { font-weight: 700; text-decoration: none; color: var(--ink); font-size: 1.1rem; }
  nav.breadcrumb { font-size: 0.82rem; color: var(--ink); opacity: 0.68; margin-bottom: 20px; }
  nav.breadcrumb a { color: var(--teal-deep); text-decoration: none; }
  nav.breadcrumb a:hover { text-decoration: underline; }
  h1 { font-family: 'Fraunces', serif; font-size: 1.6rem; margin-bottom: 4px; }
  .subtitle { color: var(--ink); opacity: 0.68; margin-bottom: 24px; }
  .card-grid { padding: 0; margin: 0; }
  .venue-card, .category-card { list-style: none; border: 1px solid var(--sand-deep); border-radius: 10px; padding: 16px 18px; margin-bottom: 14px; }
  .venue-card h2, .category-card h2 { font-family: 'Fraunces', serif; font-size: 1.05rem; margin: 0 0 4px; }
  .venue-card h2 a, .category-card h2 a { color: var(--ink); text-decoration: none; }
  .venue-card h2 a:hover, .category-card h2 a:hover { text-decoration: underline; }
  .venue-meta { color: var(--ink); opacity: 0.68; font-size: 0.85rem; margin: 0 0 8px; }
  .venue-card p, .category-card p { margin: 0 0 8px; font-size: 0.95rem; }
  .chips { display: flex; flex-wrap: wrap; gap: 6px; }
  .chip { background: var(--sand-deep); color: var(--plum); font-size: 0.75rem; padding: 3px 9px; border-radius: 999px; }
  .related-section { margin-top: 32px; }
  .related-section h2 { font-family: 'Fraunces', serif; font-size: 1.15rem; margin-bottom: 12px; }
  .related-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 10px; }
  .related-card { border: 1px solid var(--sand-deep); border-radius: 8px; padding: 10px 12px; }
  .related-card a { font-weight: 600; text-decoration: none; color: var(--ink); }
  .related-card .related-meta { font-size: 0.8rem; color: var(--ink); opacity: 0.68; }
  .detail-row { display: flex; gap: 8px; margin: 4px 0; font-size: 0.95rem; }
  .detail-row .label { color: var(--ink); opacity: 0.68; min-width: 90px; }
  .cta { display: inline-block; margin-top: 28px; background: var(--plum); color: var(--paper); text-decoration: none; padding: 12px 22px; border-radius: 8px; font-weight: 600; }
  .cta.secondary { background: var(--paper); color: var(--plum); border: 1px solid var(--plum); }
  .hours-list { list-style: none; padding: 0; margin: 8px 0; font-size: 0.9rem; }
  .hours-list li { display: flex; justify-content: space-between; max-width: 260px; padding: 2px 0; }
  footer.site-footer { margin-top: 40px; font-size: 0.85rem; color: var(--ink); opacity: 0.68; }
`;

function pageHead(title, description, canonical, jsonLdBlocks) {
  return `<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(title)}</title>
<meta name="description" content="${escapeHtml(description)}">
<link rel="canonical" href="${canonical}">
<meta property="og:type" content="website">
<meta property="og:title" content="${escapeHtml(title)}">
<meta property="og:description" content="${escapeHtml(description)}">
<meta property="og:image" content="https://okanaganroam.com/og-image.png">
<meta property="og:url" content="${canonical}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${escapeHtml(title)}">
<meta name="twitter:description" content="${escapeHtml(description)}">
${jsonLdBlocks.map((block) => `<script type="application/ld+json">\n${JSON.stringify(block)}\n</script>`).join('\n')}
<link rel="stylesheet" href="/styles/tokens.css">
<style>${SEO_PAGE_CSS}</style>`;
}

function siteHeader(rightLinkHref, rightLinkText) {
  return `<header class="top">
    <a class="brand" href="https://okanaganroam.com/">Okanagan Roam</a>
    <a href="${rightLinkHref}">${escapeHtml(rightLinkText)}</a>
  </header>`;
}

function siteFooter() {
  return `<footer class="site-footer">Okanagan Roam &middot; <a href="https://okanaganroam.com/">okanaganroam.com</a></footer>`;
}

// ---------- Phase 5 Sprint 1 — shared presentation components ----------
// Small, reusable functions extending the pageHead/siteHeader/siteFooter
// pattern already established above. Each one replaces markup that was
// previously duplicated (in slightly different shapes) across two or more
// of the four render*Page functions below. Nothing here changes any URL,
// slug, canonical, JSON-LD, or metadata behavior — these only produce the
// human-visible HTML fragments that sit inside the unchanged page shells.

// Visible breadcrumb <nav>, as opposed to breadcrumbListSchema() above
// (which produces the separate, JSON-LD structured-data version of the
// same information). items: [{ name, href }], in order from Home to the
// current page. The current/last item is rendered as plain text, not a
// link, matching every existing call site's behavior.
function breadcrumbNavHtml(items) {
  const parts = items.map((item, i) => {
    const isLast = i === items.length - 1;
    return isLast || !item.href
      ? escapeHtml(item.name)
      : `<a href="${item.href}">${escapeHtml(item.name)}</a>`;
  });
  return `<nav class="breadcrumb">${parts.join(' &rsaquo; ')}</nav>`;
}

// The `<span class="chip">` badge row used on venue/category/guide pages —
// one chip per true boolean amenity flag on the venue. Identical output to
// what all three call sites built inline before this extraction.
function badgeChipsHtml(venue) {
  return BOOL_FIELDS.filter((f) => venue[f])
    .map((f) => `<span class="chip">${escapeHtml(BADGE_LABELS[f].title)}</span>`)
    .join(' ');
}

// The `<li class="venue-card">` list-item used on category and guide
// pages. The two previous call sites differed only in whether the venue
// type itself appears in the meta line (guide pages, which mix
// categories, show it; category pages, which are already scoped to one
// category, don't) and in how defensively the name needs to be linked
// (guide pages tolerate a venue with no slug/category mapping yet by
// falling back to plain text; category pages always have both). Both
// behaviors are preserved exactly via the options below.
function venueCardHtml(venue, opts = {}) {
  const { showType = false } = opts;
  const catSlug = CATEGORY_SLUGS[venue.type];
  const href = (venue.slug && catSlug) ? `/${venue.region}/${catSlug}/${venue.slug}` : null;
  const nameHtml = href
    ? `<a href="${href}">${escapeHtml(venue.name)}</a>`
    : escapeHtml(venue.name);
  const meta = [
    showType && venue.type ? escapeHtml(venue.type) : null,
    venue.cuisine ? escapeHtml(venue.cuisine) : null,
    venue.rating ? `${venue.rating}\u2605` : null,
  ].filter(Boolean).join(' &middot; ');
  const desc = venue.description ? `<p>${escapeHtml(venue.description)}</p>` : '';
  return `
      <li class="venue-card">
        <h2>${nameHtml}</h2>
        <p class="venue-meta">${meta}</p>
        ${desc}
        <p class="chips">${badgeChipsHtml(venue)}</p>
      </li>`;
}

// GET /:region — region hub page
function renderRegionPage(region, categoryCounts, regionGuidePages) {
  const regionLabel = REGION_LABELS[region];
  const totalVenues = Object.values(categoryCounts).reduce((a, b) => a + b, 0);
  const title = `${regionLabel} Restaurants, Wineries & More, BC | Okanagan Roam`;
  const description = `${totalVenues} verified venues in ${regionLabel}, BC — browse restaurants, wineries, breweries, cafes, pubs, and cocktail lounges, all reviewed and badge-checked by Okanagan Roam.`;
  const canonical = `https://okanaganroam.com/${region}`;

  const breadcrumb = breadcrumbListSchema([
    { name: 'Home', url: 'https://okanaganroam.com/' },
    { name: regionLabel, url: canonical },
  ]);

  const categoryCards = Object.keys(CATEGORY_SLUGS)
    .filter((type) => categoryCounts[type] >= MIN_CATEGORY_VENUES)
    .sort((a, b) => categoryCounts[b] - categoryCounts[a])
    .map((type) => {
      const catSlug = CATEGORY_SLUGS[type];
      const label = CATEGORY_LABELS[type];
      return `
      <li class="category-card">
        <h2><a href="/${region}/${catSlug}">${escapeHtml(label.plural)}</a></h2>
        <p class="venue-meta">${categoryCounts[type]} ${categoryCounts[type] === 1 ? label.singular.toLowerCase() : label.plural.toLowerCase()} in ${escapeHtml(regionLabel)}</p>
      </li>`;
    })
    .join('\n');

  const guideLinks = regionGuidePages.length
    ? `<div class="related-section">
        <h2>Browse ${escapeHtml(regionLabel)} by what matters to you</h2>
        <p>${regionGuidePages
          .map((c) => `<a href="/guide/${c.region}/${c.badge}">${escapeHtml(BADGE_LABELS[c.badge].title)} (${c.count})</a>`)
          .join(', ')}</p>
      </div>`
    : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
${pageHead(title, description, canonical, [breadcrumb])}
</head>
<body>
  ${siteHeader('https://okanaganroam.com/', 'Explore the full directory \u2192')}
  ${breadcrumbNavHtml([
    { name: 'Home', href: '/' },
    { name: regionLabel },
  ])}
  <h1>${escapeHtml(regionLabel)}, BC</h1>
  <p class="subtitle">${totalVenues} verified venues across ${categoryCards ? Object.keys(categoryCounts).length : 0} categories in ${escapeHtml(regionLabel)}.</p>
  <ul class="card-grid">
    ${categoryCards}
  </ul>
  ${guideLinks}
  <a class="cta" href="https://okanaganroam.com/">See all of ${escapeHtml(regionLabel)} on Okanagan Roam</a>
  ${siteFooter()}
</body>
</html>`;
}

// GET /:region/:category — category page within a region
function renderCategoryPage(region, type, venues, categoryGuidePages) {
  const regionLabel = REGION_LABELS[region];
  const catSlug = CATEGORY_SLUGS[type];
  const label = CATEGORY_LABELS[type];
  const title = `${label.plural} in ${regionLabel}, BC | Okanagan Roam`;
  const description = `${venues.length} verified ${label.plural.toLowerCase()} in ${regionLabel}, BC — real listings with hours, ratings, and attributes, reviewed and badge-checked by Okanagan Roam.`;
  const canonical = `https://okanaganroam.com/${region}/${catSlug}`;

  const breadcrumb = breadcrumbListSchema([
    { name: 'Home', url: 'https://okanaganroam.com/' },
    { name: regionLabel, url: `https://okanaganroam.com/${region}` },
    { name: label.plural, url: canonical },
  ]);

  const itemList = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: title,
    description,
    itemListElement: venues.map((v, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      url: `https://okanaganroam.com/${region}/${catSlug}/${v.slug}`,
      item: {
        '@type': SCHEMA_TYPE_MAP[v.type] || 'LocalBusiness',
        name: v.name,
        description: v.description || undefined,
      },
    })),
  };

  const cards = venues.map((v) => venueCardHtml(v)).join('\n');

  const guideLinks = categoryGuidePages.length
    ? `<div class="related-section">
        <h2>Filter ${escapeHtml(label.plural)} in ${escapeHtml(regionLabel)}</h2>
        <p>${categoryGuidePages
          .map((c) => `<a href="/guide/${c.region}/${c.badge}">${escapeHtml(BADGE_LABELS[c.badge].title)}</a>`)
          .join(', ')}</p>
      </div>`
    : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
${pageHead(title, description, canonical, [breadcrumb, itemList])}
</head>
<body>
  ${siteHeader('https://okanaganroam.com/', 'Explore the full directory \u2192')}
  ${breadcrumbNavHtml([
    { name: 'Home', href: '/' },
    { name: regionLabel, href: `/${region}` },
    { name: label.plural },
  ])}
  <h1>${escapeHtml(label.plural)} in ${escapeHtml(regionLabel)}, BC</h1>
  <p class="subtitle">${venues.length} verified ${escapeHtml(label.plural.toLowerCase())} in ${escapeHtml(regionLabel)}.</p>
  <ul class="card-grid">
    ${cards}
  </ul>
  ${guideLinks}
  <a class="cta" href="/${region}">Back to all of ${escapeHtml(regionLabel)}</a>
  ${siteFooter()}
</body>
</html>`;
}

// GET /:region/:category/:slug — individual venue page
function renderVenuePage(venue, relatedVenues, nearbyVenues, venueGuidePages) {
  const regionLabel = REGION_LABELS[venue.region];
  const catSlug = CATEGORY_SLUGS[venue.type];
  const label = CATEGORY_LABELS[venue.type];
  const canonical = `https://okanaganroam.com/${venue.region}/${catSlug}/${venue.slug}`;
  const title = `${venue.name} \u2014 ${label.singular} in ${regionLabel}, BC | Okanagan Roam`;
  const rawDesc = venue.description || `${venue.name} is a ${label.singular.toLowerCase()} in ${regionLabel}, BC, listed on Okanagan Roam.`;
  const description = rawDesc.length > 155 ? rawDesc.slice(0, 152).replace(/\s+\S*$/, '') + '...' : rawDesc;

  const breadcrumb = breadcrumbListSchema([
    { name: 'Home', url: 'https://okanaganroam.com/' },
    { name: regionLabel, url: `https://okanaganroam.com/${venue.region}` },
    { name: label.plural, url: `https://okanaganroam.com/${venue.region}/${catSlug}` },
    { name: venue.name, url: canonical },
  ]);

  // LocalBusiness / type-specific schema — every property below is
  // conditionally included; nothing is fabricated for fields the DB
  // doesn't have yet (address, website, image are genuinely absent for
  // essentially all venues today).
  const localBusiness = {
    '@context': 'https://schema.org',
    '@type': SCHEMA_TYPE_MAP[venue.type] || 'LocalBusiness',
    name: venue.name,
    description: venue.description || undefined,
    url: canonical,
    telephone: venue.phone || undefined,
    address: venue.address ? { '@type': 'PostalAddress', streetAddress: venue.address, addressRegion: 'BC', addressCountry: 'CA' } : undefined,
    geo: (venue.latitude && venue.longitude) ? { '@type': 'GeoCoordinates', latitude: venue.latitude, longitude: venue.longitude } : undefined,
    image: venue.image_url || undefined,
    sameAs: venue.website || undefined,
    priceRange: venue.price ? '$'.repeat(venue.price) : undefined,
    servesCuisine: venue.type === 'restaurant' && venue.cuisine ? venue.cuisine : undefined,
    aggregateRating: (venue.rating && venue.reviews) ? {
      '@type': 'AggregateRating',
      ratingValue: venue.rating,
      reviewCount: venue.reviews,
    } : undefined,
    openingHoursSpecification: buildOpeningHoursSpecification(venue.hours),
  };

  const attributeChips = badgeChipsHtml(venue);

  let hoursHtml = '';
  if (venue.hours) {
    try {
      const hoursObj = JSON.parse(venue.hours);
      const dayOrder = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
      const dayNames = { mon: 'Monday', tue: 'Tuesday', wed: 'Wednesday', thu: 'Thursday', fri: 'Friday', sat: 'Saturday', sun: 'Sunday' };
      const rows = dayOrder.map((d) => {
        const ranges = hoursObj[d];
        const text = (Array.isArray(ranges) && ranges.length)
          ? ranges.map((r) => `${r[0]}\u2013${r[1]}`).join(', ')
          : 'Closed';
        return `<li><span>${dayNames[d]}</span><span>${escapeHtml(text)}</span></li>`;
      }).join('');
      hoursHtml = `<div class="detail-row"><span class="label">Hours</span></div><ul class="hours-list">${rows}</ul>`;
    } catch (e) {
      hoursHtml = '';
    }
  }

  const detailRows = [
    ['Type', label.singular],
    ['Region', `<a href="/${venue.region}">${escapeHtml(regionLabel)}</a>`],
    venue.cuisine ? ['Cuisine', escapeHtml(venue.cuisine)] : null,
    venue.address ? ['Address', escapeHtml(venue.address)] : null,
    venue.phone ? ['Phone', `<a href="tel:${escapeHtml(venue.phone)}">${escapeHtml(venue.phone)}</a>`] : null,
    venue.website ? ['Website', `<a href="${escapeHtml(venue.website)}" rel="nofollow noopener" target="_blank">${escapeHtml(venue.website)}</a>`] : null,
    venue.price ? ['Price', '$'.repeat(venue.price)] : null,
    (venue.rating && venue.reviews) ? ['Rating', `${venue.rating}\u2605 (${venue.reviews} reviews)`] : (venue.rating ? ['Rating', `${venue.rating}\u2605`] : null),
  ].filter(Boolean)
    .map(([lbl, val]) => `<div class="detail-row"><span class="label">${escapeHtml(lbl)}</span><span>${val}</span></div>`)
    .join('\n');

  const imageHtml = venue.image_url
    ? `<img src="${escapeHtml(venue.image_url)}" alt="${escapeHtml(venue.name)}" style="width:100%;max-height:340px;object-fit:cover;border-radius:10px;margin-bottom:20px;">`
    : '';

  function relatedCard(v) {
    const meta = [v.cuisine, v.rating ? `${v.rating}\u2605` : null].filter(Boolean).join(' \u00b7 ');
    return `<div class="related-card">
      <a href="/${v.region}/${CATEGORY_SLUGS[v.type]}/${v.slug}">${escapeHtml(v.name)}</a>
      <div class="related-meta">${escapeHtml(meta)}</div>
    </div>`;
  }

  const relatedHtml = relatedVenues.length
    ? `<div class="related-section">
        <h2>Other ${escapeHtml(label.plural.toLowerCase())} in ${escapeHtml(regionLabel)}</h2>
        <div class="related-grid">${relatedVenues.map(relatedCard).join('')}</div>
      </div>`
    : '';

  const nearbyHtml = nearbyVenues.length
    ? `<div class="related-section">
        <h2>More to explore near ${escapeHtml(regionLabel)}</h2>
        <div class="related-grid">${nearbyVenues.map(relatedCard).join('')}</div>
      </div>`
    : '';

  const guideLinks = venueGuidePages.length
    ? `<p class="venue-meta">Also see: ${venueGuidePages.map((c) => `<a href="/guide/${c.region}/${c.badge}">${escapeHtml(BADGE_LABELS[c.badge].title)} in ${escapeHtml(regionLabel)}</a>`).join(', ')}</p>`
    : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
${pageHead(title, description, canonical, [breadcrumb, localBusiness])}
</head>
<body>
  ${siteHeader('https://okanaganroam.com/', 'Explore the full directory \u2192')}
  ${breadcrumbNavHtml([
    { name: 'Home', href: '/' },
    { name: regionLabel, href: `/${venue.region}` },
    { name: label.plural, href: `/${venue.region}/${catSlug}` },
    { name: venue.name },
  ])}
  ${imageHtml}
  <h1>${escapeHtml(venue.name)}</h1>
  <p class="subtitle">${escapeHtml(label.singular)} in ${escapeHtml(regionLabel)}, BC</p>
  <p>${escapeHtml(venue.description || '')}</p>
  <p class="chips">${attributeChips}</p>
  ${detailRows}
  ${hoursHtml}
  ${guideLinks}
  ${relatedHtml}
  ${nearbyHtml}
  <a class="cta" href="/${venue.region}/${catSlug}">Back to ${escapeHtml(label.plural)} in ${escapeHtml(regionLabel)}</a>
  <a class="cta secondary" href="/${venue.region}">Explore all of ${escapeHtml(regionLabel)}</a>
  ${siteFooter()}
</body>
</html>`;
}

function render404Page(pathname) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Page Not Found | Okanagan Roam</title>
<meta name="robots" content="noindex">
<style>body{font-family:-apple-system,sans-serif;max-width:600px;margin:80px auto;text-align:center;color:#1f2933;}a{color:#0b6e4f;}</style>
</head>
<body>
  <h1>Page not found</h1>
  <p>We couldn't find a venue or page at that address.</p>
  <a href="https://okanaganroam.com/">Back to Okanagan Roam</a>
</body>
</html>`;
}

function renderOpenNowScript() {
  // Self-contained "Open Now" toggle. Deliberately does NOT touch the app's
  // own filter/search logic (activeFilters Set, applyFilters(), etc.) —
  // instead it piggybacks on something the app already computes for us:
  // every rendered .venue-card already carries a child element with class
  // "open-status-open" or "open-status-closed" (used to show the "Open
  // now" / "Closed now" text). We just show/hide whole cards based on
  // that existing, already-correct, already-timezone-aware computation.
  //
  // Because search/filter/pagination re-renders the .venue-grid contents
  // via React, we re-apply on every DOM mutation (rAF-debounced so it's
  // cheap) rather than trying to hook into the app's own render cycle.
  return `
<script>
(function(){
  var D = document;
  var active = false;
  var scheduled = false;

  function apply(){
    var cards = D.querySelectorAll('.venue-card');
    for (var i = 0; i < cards.length; i++) {
      var card = cards[i];
      if (!active) { card.style.display = ''; continue; }
      var isOpen = card.querySelector('.open-status-open');
      card.style.display = isOpen ? '' : 'none';
    }
  }

  function scheduleApply(){
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function(){ scheduled = false; apply(); });
  }

  function ensureButton(){
    if (D.querySelector('.og-open-now-btn')) return;
    var btn = D.createElement('button');
    btn.type = 'button';
    btn.className = 'og-open-now-btn';
    btn.textContent = 'Open Now';
    btn.setAttribute('aria-pressed', 'false');
    // Fixed position, not appended into .results-head: that element can
    // render thousands of pixels down this long-scrolling page, making a
    // button placed there effectively invisible without scrolling. A
    // fixed pill stays visible and reachable no matter where the user is.
    //
    // Position differs by viewport width because the app already claims
    // the bottom of the screen for its own UI: the "Your trip" widget
    // sits bottom-right on all sizes, and on narrow/mobile viewports the
    // wizard's step "Continue" button becomes a bottom-anchored bar too.
    // Bottom-left is clear on desktop, but not reliably clear on mobile,
    // so on narrow screens we place it just under the sticky header
    // instead, which stays clear of both.
    var isNarrow = window.matchMedia('(max-width: 700px)').matches;
    btn.style.cssText = isNarrow
      ? 'position:fixed;left:12px;top:80px;z-index:2147483000;padding:8px 14px;border-radius:999px;border:1px solid #0b6e4f;background:#fff;color:#0b6e4f;font-size:13px;font-weight:600;cursor:pointer;transition:background .15s,color .15s;font-family:inherit;box-shadow:0 2px 10px rgba(0,0,0,.15);'
      : 'position:fixed;left:16px;bottom:16px;z-index:2147483000;padding:10px 18px;border-radius:999px;border:1px solid #0b6e4f;background:#fff;color:#0b6e4f;font-size:14px;font-weight:600;cursor:pointer;transition:background .15s,color .15s;font-family:inherit;box-shadow:0 2px 10px rgba(0,0,0,.15);';
    btn.addEventListener('click', function(){
      active = !active;
      btn.setAttribute('aria-pressed', String(active));
      btn.style.background = active ? '#0b6e4f' : '#fff';
      btn.style.color = active ? '#fff' : '#0b6e4f';
      apply();
    });
    D.body.appendChild(btn);
  }

  var observer = new MutationObserver(function(){
    ensureButton();
    scheduleApply();
  });
  observer.observe(D.body, { childList: true, subtree: true });

  ensureButton();
  scheduleApply();

  // The search wizard panel is supposed to scroll away once the person
  // starts browsing results, but it's pinned in place: .filter-bar has
  // position:sticky, top:0, which keeps it stuck to the top of the
  // viewport regardless of scroll position or the wizard-active class.
  // Past a small scroll threshold, drop it to static so it scrolls away
  // normally; restore sticky at the very top.
  var wizardScrollHandler = function(){
    var bar = D.querySelector('.filter-bar');
    if (window.scrollY > 80) {
      D.body.classList.remove('wizard-active');
      if (bar) bar.style.setProperty('position', 'static', 'important');
    } else {
      D.body.classList.add('wizard-active');
      if (bar) bar.style.removeProperty('position');
    }
  };
  window.addEventListener('scroll', wizardScrollHandler, { passive: true });
  wizardScrollHandler();
})();
</script>`;
}

function renderHiddenElementsScript() {
  // Hides two existing UI pieces the site owner asked to remove: the
  // "Open the map view" toggle and the "Live search the whole Okanagan
  // (beta)" panel. Also rounds the big "N places to explore" count down
  // to a friendly "1000+" display once it crosses 1000, rather than
  // showing the exact, ever-growing venue count (which will keep
  // climbing as more venues get added and would otherwise need editing
  // here every time). Smaller/filtered counts are left exact — this
  // only kicks in once the number is genuinely in the thousands.
  //
  // History: first tried a plain <style> tag — didn't survive the app's
  // DOM lifecycle (only one <style> element, the app's own, ever ended
  // up in the live DOM). Then tried the MutationObserver technique that
  // works for the Open Now button — the elements still resurfaced,
  // meaning whatever re-renders them isn't reliably caught as a
  // childList/subtree mutation in time. Verified live in the browser
  // console that a simple interval-based poll reliably keeps them
  // hidden, so that's what this uses: cheap, and doesn't depend on
  // guessing exactly when/how the app re-renders these elements.
  return `
<script>
(function(){
  var D = document;
  function apply(){
    var toHide = D.querySelectorAll('.map-toggle-row, .live-search');
    for (var i = 0; i < toHide.length; i++) {
      toHide[i].style.display = 'none';
    }
    var countEl = D.querySelector('.results-count');
    if (countEl) {
      var m = countEl.textContent.match(/^([\\d,]+)(\\s.*)$/);
      if (m) {
        var n = parseInt(m[1].replace(/,/g, ''), 10);
        if (n >= 1000 && !/^1000\\+/.test(countEl.textContent)) {
          countEl.textContent = '1000+' + m[2];
        }
      }
    }
    // The data-sourcing disclaimer paragraph has no class to target, so
    // match on its distinctive opening text instead.
    var ps = D.querySelectorAll('p');
    for (var j = 0; j < ps.length; j++) {
      if (/^Every place below is a real Okanagan venue/.test(ps[j].textContent.trim())) {
        ps[j].style.display = 'none';
      }
    }
    // The app's own CSS clamps .venue-desc to 5 lines with overflow:hidden,
    // which truncated the longer, rewritten venue descriptions with no way
    // to read the rest. Re-clamp to 6 lines (keeps card heights aligned in
    // the grid) and add a "Read more" toggle for any description that
    // actually overflows. data-desc-init marks elements already processed
    // so we don't reprocess them (and don't re-clamp one a user just
    // expanded) on every 300ms poll.
    var descs = D.querySelectorAll('.venue-desc:not([data-desc-init])');
    for (var k = 0; k < descs.length; k++) {
      var desc = descs[k];
      desc.setAttribute('data-desc-init', '1');
      desc.style.setProperty('display', '-webkit-box', 'important');
      desc.style.setProperty('-webkit-box-orient', 'vertical', 'important');
      desc.style.setProperty('-webkit-line-clamp', '6', 'important');
      desc.style.setProperty('overflow', 'hidden', 'important');
      desc.style.setProperty('max-height', 'none', 'important');
      desc.style.setProperty('min-height', '0', 'important');

      if (desc.scrollHeight > desc.clientHeight + 2) {
        var btn = D.createElement('button');
        btn.type = 'button';
        btn.textContent = 'Read more';
        btn.style.cssText = 'display:block;margin:4px 22px 0;padding:0;border:none;background:none;color:#8A631F;font-size:0.85rem;font-weight:700;cursor:pointer;text-decoration:underline;';
        var expanded = false;
        btn.addEventListener('click', function(el, b){
          return function(){
            expanded = !expanded;
            if (expanded) {
              el.style.setProperty('-webkit-line-clamp', 'unset', 'important');
              el.style.setProperty('overflow', 'visible', 'important');
              b.textContent = 'Read less';
            } else {
              el.style.setProperty('-webkit-line-clamp', '6', 'important');
              el.style.setProperty('overflow', 'hidden', 'important');
              b.textContent = 'Read more';
            }
          };
        }(desc, btn));
        desc.insertAdjacentElement('afterend', btn);
      }
    }
  }
  apply();
  setInterval(apply, 300);
})();
</script>`;
}




const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const { pathname, query } = parsed;
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    });
    return res.end();
  }

  try {
    // Serve the website itself at / and /okanagan.html, so this same
    // deployment is both the API and the live site.
    if ((pathname === '/' || pathname === '/okanagan.html') && method === 'GET') {
      if (fs.existsSync(SITE_PATH)) {
        let html = fs.readFileSync(SITE_PATH, 'utf8');
        // Inject real, crawlable internal links to the guide pages so search
        // engines can discover them by following links from the homepage,
        // not just via the sitemap (which some crawlers deprioritize). This
        // is plain visible HTML, not hidden/cloaked content.
        const footer = renderGuideFooterHTML();
        const openNowScript = renderOpenNowScript();
        const hiddenElementsScript = renderHiddenElementsScript();
        html = html.includes('</body>')
          ? html.replace('</body>', `${footer}\n${openNowScript}\n${hiddenElementsScript}\n</body>`)
          : html + footer + openNowScript + hiddenElementsScript;
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        return res.end(html);
      }
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('okanagan.html not found on server');
    }

    // IndexNow key file — required at the domain root so search engines can
    // verify submissions actually come from whoever controls this site.
    if (pathname === `/${INDEXNOW_KEY}.txt` && method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end(INDEXNOW_KEY);
    }

    // robots.txt — points crawlers at the sitemap and allows everything
    // except the read/write API endpoints, which have no SEO value and
    // shouldn't be indexed as pages.
    if (pathname === '/robots.txt' && method === 'GET') {
      const robots = [
        'User-agent: *',
        'Allow: /',
        'Disallow: /api/',
        '',
        'Sitemap: https://okanaganroam.com/sitemap.xml',
        '',
      ].join('\n');
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end(robots);
    }

    // sitemap.xml — the homepage, plus one URL per region+badge guide page
    // that has enough venues to be worth indexing. This list is computed
    // live from the DB, so it grows automatically as more venues get badges.
    if (pathname === '/sitemap.xml' && method === 'GET') {
      const today = new Date().toISOString().slice(0, 10);
      const combos = listGuideCombos(MIN_GUIDE_VENUES);

      // Region pages: one per region that has at least one venue.
      const regionCounts = db
        .prepare('SELECT region, COUNT(*) AS n FROM venues WHERE redirect_to IS NULL GROUP BY region')
        .all()
        .filter((r) => REGION_LABELS[r.region] && r.n > 0);

      // Category pages: one per region+type combo that has at least one
      // venue — computed live, same pattern as the guide-page combos above.
      const categoryCombos = db
        .prepare('SELECT region, type, COUNT(*) AS n FROM venues WHERE redirect_to IS NULL GROUP BY region, type')
        .all()
        .filter((r) => REGION_LABELS[r.region] && CATEGORY_SLUGS[r.type] && r.n > 0);

      // Venue pages: every venue that has a real, non-null slug (should be
      // all of them after the startup backfill, but this guards against any
      // edge case rather than emitting a broken sitemap entry).
      const venueRows = db
        .prepare('SELECT region, type, slug FROM venues WHERE slug IS NOT NULL AND redirect_to IS NULL')
        .all()
        .filter((v) => REGION_LABELS[v.region] && CATEGORY_SLUGS[v.type]);

      const urlEntries = [
        `  <url>\n    <loc>https://okanaganroam.com/</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>`,
        ...regionCounts.map(
          ({ region }) =>
            `  <url>\n    <loc>https://okanaganroam.com/${region}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>\n  </url>`
        ),
        ...categoryCombos.map(
          ({ region, type }) =>
            `  <url>\n    <loc>https://okanaganroam.com/${region}/${CATEGORY_SLUGS[type]}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.7</priority>\n  </url>`
        ),
        ...combos.map(
          ({ region, badge }) =>
            `  <url>\n    <loc>https://okanaganroam.com/guide/${region}/${badge}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.7</priority>\n  </url>`
        ),
        ...venueRows.map(
          ({ region, type, slug }) =>
            `  <url>\n    <loc>https://okanaganroam.com/${region}/${CATEGORY_SLUGS[type]}/${slug}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.6</priority>\n  </url>`
        ),
      ];
      const sitemap = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
        ...urlEntries,
        '</urlset>',
        '',
      ].join('\n');
      res.writeHead(200, { 'Content-Type': 'application/xml; charset=utf-8' });
      return res.end(sitemap);
    }


    // Open Graph / Twitter Card preview image, referenced from the HTML
    // <head> so shared links show a proper branded thumbnail instead of a
    // blank box on Facebook, Twitter/X, Slack, iMessage, etc.
    if (pathname === '/og-image.png' && method === 'GET') {
      const ogPath = path.join(__dirname, 'og-image.png');
      if (fs.existsSync(ogPath)) {
        const image = fs.readFileSync(ogPath);
        res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=86400' });
        return res.end(image);
      }
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('og-image.png not found on server');
    }

    // Phase 5 Sprint 1 — shared static assets. These three files are the
    // extracted, single-source-of-truth CSS/JS that both the SPA
    // (okanagan.html, via <link>/<script src>) and the server-rendered SEO
    // pages (via pageHead()'s tokens.css <link>) now depend on. Served the
    // same simple way as og-image.png above: read from disk, no build step,
    // no bundler. Cached for an hour rather than a day (unlike og-image.png)
    // since these are actively being iterated on during Phase 5.
    const STATIC_ASSETS = {
      '/styles/tokens.css': { file: 'public/styles/tokens.css', type: 'text/css; charset=utf-8' },
      '/styles/app.css': { file: 'public/styles/app.css', type: 'text/css; charset=utf-8' },
      '/scripts/app.js': { file: 'public/scripts/app.js', type: 'application/javascript; charset=utf-8' },
    };
    if (STATIC_ASSETS[pathname] && method === 'GET') {
      const asset = STATIC_ASSETS[pathname];
      const assetPath = path.join(__dirname, asset.file);
      if (fs.existsSync(assetPath)) {
        const body = fs.readFileSync(assetPath, 'utf8');
        res.writeHead(200, { 'Content-Type': asset.type, 'Cache-Control': 'public, max-age=3600' });
        return res.end(body);
      }
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end(`${pathname} not found on server`);
    }

    // GET /guide/:region/:badge — server-rendered SEO landing page.
    const guideMatch = pathname.match(/^\/guide\/([a-z-]+)\/([a-z_]+)\/?$/);
    if (guideMatch && method === 'GET') {
      const region = guideMatch[1];
      const badge = guideMatch[2];
      if (REGION_LABELS[region] && BOOL_FIELDS.includes(badge)) {
        const rows = db
          .prepare(`SELECT * FROM venues WHERE region = ? AND ${badge} = 1 AND redirect_to IS NULL ORDER BY reviews DESC`)
          .all(region);
        if (rows.length >= MIN_GUIDE_VENUES) {
          const html = renderGuidePage(region, badge, rows.map(rowToVenue));
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          return res.end(html);
        }
      }
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Guide page not found');
    }

    // GET /admin/indexnow-submit?key=<INDEXNOW_KEY>
    //
    // Triggers a server-side bulk submission of every URL in the sitemap to
    // the IndexNow API (api.indexnow.org), which fans out to Bing, Yandex,
    // Seznam, and other participating engines. This has to happen
    // server-side rather than from a browser: IndexNow's bulk POST endpoint
    // doesn't send CORS headers, so browser JS gets silently blocked, while
    // a server calling another server has no such restriction.
    //
    // Protected by requiring the IndexNow key itself as a query param —
    // not real auth, just enough to keep this off search-engine crawlers'
    // radar as a normal page (it's already excluded via robots.txt-style
    // reasoning: nobody guesses a 32-char hex key by accident). Re-run this
    // any time a bunch of venues get new badges and you want search engines
    // to know sooner than the next passive sitemap crawl.
    if (pathname === '/admin/indexnow-submit' && method === 'GET') {
      if (query.key !== INDEXNOW_KEY) {
        res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('Forbidden');
      }
      const today = new Date().toISOString().slice(0, 10);
      const combos = listGuideCombos(MIN_GUIDE_VENUES);
      const urlList = [
        'https://okanaganroam.com/',
        ...combos.map(({ region, badge }) => `https://okanaganroam.com/guide/${region}/${badge}`),
      ];
      try {
        const submitRes = await fetch('https://api.indexnow.org/indexnow', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json; charset=utf-8' },
          body: JSON.stringify({
            host: 'okanaganroam.com',
            key: INDEXNOW_KEY,
            keyLocation: `https://okanaganroam.com/${INDEXNOW_KEY}.txt`,
            urlList,
          }),
        });
        const bodyText = await submitRes.text();
        return sendJSON(res, 200, {
          submitted_at: today,
          url_count: urlList.length,
          indexnow_status: submitRes.status,
          indexnow_response: bodyText || '(empty body — normal for a 200/202 success)',
        });
      } catch (err) {
        return sendJSON(res, 502, { error: `IndexNow submission failed: ${err.message}` });
      }
    }

    // POST /admin/enrich-venue
    //
    // The ONLY invocation path for guardedEnrichUpdate(). Deliberately
    // narrow: one venue per call, exactly three allowed fields, no read
    // functionality beyond confirming what was actually written, no path
    // to updateVenue() or any other write function, no arbitrary SQL or
    // column names possible (the three field names are hardcoded below,
    // never taken from the request).
    if (pathname === '/admin/enrich-venue' && method === 'POST') {
      // Fail CLOSED if the secret isn't configured — never fall back to
      // an unauthenticated or default-permitted state.
      if (!ENRICHMENT_ADMIN_TOKEN) {
        return sendJSON(res, 503, { error: 'Enrichment endpoint is not configured.' });
      }

      const authHeader = req.headers['authorization'] || '';
      const match = /^Bearer (.+)$/.exec(authHeader);
      if (!match || !safeTokenEquals(match[1], ENRICHMENT_ADMIN_TOKEN)) {
        return sendJSON(res, 401, { error: 'Unauthorized.' });
      }

      let body;
      try {
        body = await readBody(req);
      } catch (err) {
        return sendJSON(res, 400, { error: 'Malformed JSON body.' });
      }

      // --- id validation ---
      const id = body.id;
      if (!Number.isInteger(id) || id <= 0) {
        return sendJSON(res, 400, { error: 'id must be a positive integer.' });
      }

      // --- allowlist validation: reject the WHOLE request if any
      // unexpected key is present, rather than silently ignoring it ---
      const ALLOWED_ENRICH_KEYS = ['id', 'address', 'latitude', 'longitude'];
      const unexpectedKeys = Object.keys(body).filter((k) => !ALLOWED_ENRICH_KEYS.includes(k));
      if (unexpectedKeys.length > 0) {
        return sendJSON(res, 400, { error: `Unexpected field(s): ${unexpectedKeys.join(', ')}` });
      }

      const hasAddress = body.address !== undefined;
      const hasLat = body.latitude !== undefined;
      const hasLng = body.longitude !== undefined;
      if (!hasAddress && !hasLat && !hasLng) {
        return sendJSON(res, 400, { error: 'At least one of address, latitude, longitude is required.' });
      }

      // --- per-field validation, no silent coercion ---
      if (hasAddress && (typeof body.address !== 'string' || body.address.trim() === '')) {
        return sendJSON(res, 400, { error: 'address must be a non-empty string.' });
      }
      // Okanagan Valley sanity bounds, deliberately tighter than global
      // lat/long ranges — this app only ever covers this one region, so a
      // coordinate outside this box is almost certainly wrong data, not a
      // legitimate edge case.
      const OKANAGAN_LAT_RANGE = [48.5, 51.0];
      const OKANAGAN_LNG_RANGE = [-121.0, -118.0];
      if (hasLat) {
        if (typeof body.latitude !== 'number' || !Number.isFinite(body.latitude)) {
          return sendJSON(res, 400, { error: 'latitude must be a finite number.' });
        }
        if (body.latitude < OKANAGAN_LAT_RANGE[0] || body.latitude > OKANAGAN_LAT_RANGE[1]) {
          return sendJSON(res, 400, { error: 'latitude is outside the expected Okanagan range.' });
        }
      }
      if (hasLng) {
        if (typeof body.longitude !== 'number' || !Number.isFinite(body.longitude)) {
          return sendJSON(res, 400, { error: 'longitude must be a finite number.' });
        }
        if (body.longitude < OKANAGAN_LNG_RANGE[0] || body.longitude > OKANAGAN_LNG_RANGE[1]) {
          return sendJSON(res, 400, { error: 'longitude is outside the expected Okanagan range.' });
        }
      }

      // Build the payload for guardedEnrichUpdate() using ONLY the three
      // hardcoded field names below — the request body's keys are never
      // used as column names, so arbitrary-column injection is not
      // possible through this path regardless of what a caller sends.
      const enrichData = {};
      if (hasAddress) enrichData.address = body.address;
      if (hasLat) enrichData.latitude = body.latitude;
      if (hasLng) enrichData.longitude = body.longitude;

      const result = guardedEnrichUpdate(id, enrichData);
      if (!result.found) {
        return sendJSON(res, 404, { error: 'Venue not found.' });
      }
      return sendJSON(res, 200, { id, results: result.results });
    }

    // POST /admin/correct-venue
    //
    // A separate, narrowly-scoped path for correcting address/latitude/
    // longitude that were already populated (typically incorrectly) by a
    // prior enrichment. Does not alter /admin/enrich-venue in any way --
    // entirely separate function, entirely separate route. Reuses the
    // exact same bearer-token check as /admin/enrich-venue.
    if (pathname === '/admin/correct-venue' && method === 'POST') {
      if (!ENRICHMENT_ADMIN_TOKEN) {
        return sendJSON(res, 503, { error: 'Correction endpoint is not configured.' });
      }

      const authHeader = req.headers['authorization'] || '';
      const match = /^Bearer (.+)$/.exec(authHeader);
      if (!match || !safeTokenEquals(match[1], ENRICHMENT_ADMIN_TOKEN)) {
        return sendJSON(res, 401, { error: 'Unauthorized.' });
      }

      let body;
      try {
        body = await readBody(req);
      } catch (err) {
        return sendJSON(res, 400, { error: 'Malformed JSON body.' });
      }

      // --- allowlist validation: reject the WHOLE request if any
      // unexpected top-level key is present ---
      const ALLOWED_CORRECT_KEYS = ['id', 'expected_current', 'corrected', 'reason', 'batch_id'];
      const unexpectedKeys = Object.keys(body).filter((k) => !ALLOWED_CORRECT_KEYS.includes(k));
      if (unexpectedKeys.length > 0) {
        return sendJSON(res, 400, { error: `Unexpected field(s): ${unexpectedKeys.join(', ')}` });
      }

      // --- required top-level fields ---
      const id = body.id;
      if (!Number.isInteger(id) || id <= 0) {
        return sendJSON(res, 400, { error: 'id must be a positive integer.' });
      }
      if (typeof body.reason !== 'string' || body.reason.trim() === '') {
        return sendJSON(res, 400, { error: 'reason is required and must be a non-empty string.' });
      }
      if (typeof body.batch_id !== 'string' || body.batch_id.trim() === '') {
        return sendJSON(res, 400, { error: 'batch_id is required and must be a non-empty string.' });
      }
      if (typeof body.expected_current !== 'object' || body.expected_current === null || Array.isArray(body.expected_current)) {
        return sendJSON(res, 400, { error: 'expected_current is required and must be an object.' });
      }
      if (typeof body.corrected !== 'object' || body.corrected === null || Array.isArray(body.corrected)) {
        return sendJSON(res, 400, { error: 'corrected is required and must be an object.' });
      }

      // --- expected_current and corrected must each contain exactly
      // address, latitude, longitude -- no more, no less ---
      const REQUIRED_SUBFIELDS = ['address', 'latitude', 'longitude'];
      for (const [label, obj] of [['expected_current', body.expected_current], ['corrected', body.corrected]]) {
        const keys = Object.keys(obj);
        const missing = REQUIRED_SUBFIELDS.filter((f) => !(f in obj));
        const extra = keys.filter((k) => !REQUIRED_SUBFIELDS.includes(k));
        if (missing.length > 0) {
          return sendJSON(res, 400, { error: `${label} is missing required field(s): ${missing.join(', ')}` });
        }
        if (extra.length > 0) {
          return sendJSON(res, 400, { error: `${label} has unexpected field(s): ${extra.join(', ')}` });
        }
      }

      // --- per-field validation on the CORRECTED values, reusing the
      // exact same rules and bounds as /admin/enrich-venue ---
      const { address, latitude, longitude } = body.corrected;
      if (typeof address !== 'string' || address.trim() === '') {
        return sendJSON(res, 400, { error: 'corrected.address must be a non-empty string.' });
      }
      const OKANAGAN_LAT_RANGE = [48.5, 51.0];
      const OKANAGAN_LNG_RANGE = [-121.0, -118.0];
      if (typeof latitude !== 'number' || !Number.isFinite(latitude)) {
        return sendJSON(res, 400, { error: 'corrected.latitude must be a finite number.' });
      }
      if (latitude < OKANAGAN_LAT_RANGE[0] || latitude > OKANAGAN_LAT_RANGE[1]) {
        return sendJSON(res, 400, { error: 'corrected.latitude is outside the expected Okanagan range.' });
      }
      if (typeof longitude !== 'number' || !Number.isFinite(longitude)) {
        return sendJSON(res, 400, { error: 'corrected.longitude must be a finite number.' });
      }
      if (longitude < OKANAGAN_LNG_RANGE[0] || longitude > OKANAGAN_LNG_RANGE[1]) {
        return sendJSON(res, 400, { error: 'corrected.longitude is outside the expected Okanagan range.' });
      }

      // --- basic shape validation on expected_current (values are
      // whatever the live row's current values are, so we only check
      // types here -- the atomic UPDATE's WHERE clause is what actually
      // verifies correctness against the live row) ---
      const ec = body.expected_current;
      if (ec.address !== null && typeof ec.address !== 'string') {
        return sendJSON(res, 400, { error: 'expected_current.address must be a string or null.' });
      }
      if (ec.latitude !== null && typeof ec.latitude !== 'number') {
        return sendJSON(res, 400, { error: 'expected_current.latitude must be a number or null.' });
      }
      if (ec.longitude !== null && typeof ec.longitude !== 'number') {
        return sendJSON(res, 400, { error: 'expected_current.longitude must be a number or null.' });
      }

      let result;
      try {
        result = guardedCorrectUpdate(
          id,
          { address: ec.address, latitude: ec.latitude, longitude: ec.longitude },
          { address, latitude, longitude },
          { reason: body.reason, batch_id: body.batch_id, reviewed_by: null }
        );
      } catch (err) {
        // Any failure inside the transaction (including a failed audit-
        // log insert) rolls back the venue update too -- report a clean
        // 500 rather than leaving ambiguity about what was persisted.
        return sendJSON(res, 500, { error: 'Correction failed and was rolled back.', detail: String(err.message || err) });
      }

      if (!result.found) {
        return sendJSON(res, 404, { error: 'Venue not found.' });
      }
      if (result.mismatch) {
        return sendJSON(res, 409, {
          error: 'expected_current did not match the live venue record; no changes were made.',
          live: { address: result.live.address, latitude: result.live.latitude, longitude: result.live.longitude },
        });
      }
      return sendJSON(res, 200, {
        id,
        changedFields: result.changedFields,
        venue: { address: result.venue.address, latitude: result.venue.latitude, longitude: result.venue.longitude },
      });
    }

    // POST /admin/retire-duplicate
    //
    // Sets redirect_to on a duplicate venue. Reuses the exact same
    // bearer-token check as /admin/enrich-venue and /admin/correct-venue.
    // Scoped for the 2.8D canary: accepts exactly {duplicate_id,
    // canonical_id} and nothing else.
    if (pathname === '/admin/retire-duplicate' && method === 'POST') {
      if (!ENRICHMENT_ADMIN_TOKEN) {
        return sendJSON(res, 503, { error: 'Retire-duplicate endpoint is not configured.' });
      }
      const authHeader = req.headers['authorization'] || '';
      const match = /^Bearer (.+)$/.exec(authHeader);
      if (!match || !safeTokenEquals(match[1], ENRICHMENT_ADMIN_TOKEN)) {
        return sendJSON(res, 401, { error: 'Unauthorized.' });
      }

      let body;
      try {
        body = await readBody(req);
      } catch (err) {
        return sendJSON(res, 400, { error: 'Malformed JSON body.' });
      }

      const ALLOWED_KEYS = ['duplicate_id', 'canonical_id'];
      const unexpected = Object.keys(body).filter((k) => !ALLOWED_KEYS.includes(k));
      if (unexpected.length > 0) {
        return sendJSON(res, 400, { error: `Unexpected field(s): ${unexpected.join(', ')}` });
      }
      const duplicateId = body.duplicate_id;
      const canonicalId = body.canonical_id;
      if (!Number.isInteger(duplicateId) || duplicateId <= 0) {
        return sendJSON(res, 400, { error: 'duplicate_id must be a positive integer.' });
      }
      if (!Number.isInteger(canonicalId) || canonicalId <= 0) {
        return sendJSON(res, 400, { error: 'canonical_id must be a positive integer.' });
      }

      let result;
      try {
        result = guardedRetireUpdate(duplicateId, canonicalId);
      } catch (err) {
        return sendJSON(res, 500, { error: 'Retire operation failed and was rolled back.', detail: String(err.message || err) });
      }

      if (!result.ok) {
        const statusMap = {
          self_redirect: 400,
          duplicate_not_found: 404,
          canonical_not_found: 404,
          duplicate_already_redirected: 409,
          canonical_is_itself_a_duplicate: 409,
          duplicate_is_a_canonical_for_others: 409,
          precondition_changed_mid_write: 409,
        };
        return sendJSON(res, statusMap[result.reason] || 400, { error: result.reason, detail: result });
      }
      return sendJSON(res, 200, { duplicate_id: duplicateId, canonical_id: canonicalId, venue: result.venue });
    }

    // POST /admin/correct-region
    //
    // A dedicated, standalone endpoint for the single-field region
    // correction case. Deliberately NOT part of /admin/correct-venue --
    // see guardedRegionCorrectUpdate()'s comment for why. Accepts exactly
    // {id, expected_current_region, corrected_region} and nothing else.
    if (pathname === '/admin/correct-region' && method === 'POST') {
      if (!ENRICHMENT_ADMIN_TOKEN) {
        return sendJSON(res, 503, { error: 'Correct-region endpoint is not configured.' });
      }
      const authHeader = req.headers['authorization'] || '';
      const match = /^Bearer (.+)$/.exec(authHeader);
      if (!match || !safeTokenEquals(match[1], ENRICHMENT_ADMIN_TOKEN)) {
        return sendJSON(res, 401, { error: 'Unauthorized.' });
      }

      let body;
      try {
        body = await readBody(req);
      } catch (err) {
        return sendJSON(res, 400, { error: 'Malformed JSON body.' });
      }

      const ALLOWED_KEYS = ['id', 'expected_current_region', 'corrected_region'];
      const unexpected = Object.keys(body).filter((k) => !ALLOWED_KEYS.includes(k));
      if (unexpected.length > 0) {
        return sendJSON(res, 400, { error: `Unexpected field(s): ${unexpected.join(', ')}` });
      }
      const id = body.id;
      const expectedCurrentRegion = body.expected_current_region;
      const correctedRegion = body.corrected_region;
      if (!Number.isInteger(id) || id <= 0) {
        return sendJSON(res, 400, { error: 'id must be a positive integer.' });
      }
      if (typeof expectedCurrentRegion !== 'string' || expectedCurrentRegion.length === 0) {
        return sendJSON(res, 400, { error: 'expected_current_region must be a non-empty string.' });
      }
      if (typeof correctedRegion !== 'string' || correctedRegion.length === 0) {
        return sendJSON(res, 400, { error: 'corrected_region must be a non-empty string.' });
      }

      let result;
      try {
        result = guardedRegionCorrectUpdate(id, expectedCurrentRegion, correctedRegion);
      } catch (err) {
        return sendJSON(res, 500, { error: 'Region correction failed.', detail: String(err.message || err) });
      }

      if (!result.ok) {
        const statusMap = {
          invalid_region_value: 400,
          venue_not_found: 404,
          precondition_failed_region_mismatch: 409,
          unexpected_multi_row_match: 500,
        };
        return sendJSON(res, statusMap[result.reason] || 400, { error: result.reason, detail: result });
      }
      return sendJSON(res, 200, { id, noop: result.noop, venue: result.venue });
    }

    // POST /admin/merge-and-retire-duplicate
    //
    // Scoped for the 944->210 case: transfers an explicit, hardcoded set
    // of null-vs-value fields (MERGEABLE_FIELDS) onto the canonical in
    // the SAME transaction as setting redirect_to on the duplicate.
    // Reuses the exact same bearer-token check as every other admin
    // endpoint. Does not alter /admin/enrich-venue, /admin/correct-venue,
    // or /admin/retire-duplicate in any way.
    if (pathname === '/admin/merge-and-retire-duplicate' && method === 'POST') {
      if (!ENRICHMENT_ADMIN_TOKEN) {
        return sendJSON(res, 503, { error: 'Merge-and-retire endpoint is not configured.' });
      }
      const authHeader = req.headers['authorization'] || '';
      const match = /^Bearer (.+)$/.exec(authHeader);
      if (!match || !safeTokenEquals(match[1], ENRICHMENT_ADMIN_TOKEN)) {
        return sendJSON(res, 401, { error: 'Unauthorized.' });
      }

      let body;
      try {
        body = await readBody(req);
      } catch (err) {
        return sendJSON(res, 400, { error: 'Malformed JSON body.' });
      }

      const ALLOWED_KEYS = ['duplicate_id', 'canonical_id', 'fields'];
      const unexpected = Object.keys(body).filter((k) => !ALLOWED_KEYS.includes(k));
      if (unexpected.length > 0) {
        return sendJSON(res, 400, { error: `Unexpected field(s): ${unexpected.join(', ')}` });
      }
      const duplicateId = body.duplicate_id;
      const canonicalId = body.canonical_id;
      const fields = body.fields;
      if (!Number.isInteger(duplicateId) || duplicateId <= 0) {
        return sendJSON(res, 400, { error: 'duplicate_id must be a positive integer.' });
      }
      if (!Number.isInteger(canonicalId) || canonicalId <= 0) {
        return sendJSON(res, 400, { error: 'canonical_id must be a positive integer.' });
      }
      if (typeof fields !== 'object' || fields === null || Array.isArray(fields)) {
        return sendJSON(res, 400, { error: 'fields must be an object.' });
      }

      let result;
      try {
        result = guardedMergeAndRetireUpdate(duplicateId, canonicalId, fields);
      } catch (err) {
        return sendJSON(res, 500, { error: 'Merge-and-retire failed and was rolled back.', detail: String(err.message || err) });
      }

      if (!result.ok) {
        const statusMap = {
          self_redirect: 400,
          no_merge_fields_provided: 400,
          unexpected_merge_fields: 400,
          missing_merge_fields: 400,
          duplicate_not_found: 404,
          canonical_not_found: 404,
          duplicate_already_redirected: 409,
          canonical_is_itself_a_duplicate: 409,
          duplicate_is_a_canonical_for_others: 409,
          canonical_field_not_null: 409,
          canonical_precondition_changed_mid_write: 409,
          duplicate_precondition_changed_mid_write: 409,
        };
        return sendJSON(res, statusMap[result.reason] || 400, { error: result.reason, detail: result });
      }
      return sendJSON(res, 200, { duplicate_id: duplicateId, canonical_id: canonicalId, merged_fields: result.mergedFields, canonical: result.canonical, duplicate: result.duplicate });
    }

    // GET /api/venues
    if (pathname === '/api/venues' && method === 'GET') {
      return sendJSON(res, 200, listVenues(query));
    }


    // GET /api/stats
    if (pathname === '/api/stats' && method === 'GET') {
      return sendJSON(res, 200, getStats());
    }

    // /api/venues/:id
    const venueIdMatch = pathname.match(/^\/api\/venues\/(\d+)$/);
    if (venueIdMatch) {
      const id = parseInt(venueIdMatch[1]);

      if (method === 'GET') {
        const venue = getVenue(id);
        if (!venue) return sendJSON(res, 404, { error: 'Venue not found' });
        return sendJSON(res, 200, venue);
      }

      if (method === 'PUT') {
        const body = await readBody(req);
        const updated = updateVenue(id, body);
        if (!updated) return sendJSON(res, 404, { error: 'Venue not found' });
        return sendJSON(res, 200, updated);
      }

      if (method === 'DELETE') {
        const deleted = deleteVenue(id);
        if (!deleted) return sendJSON(res, 404, { error: 'Venue not found' });
        return sendJSON(res, 200, { success: true });
      }
    }

    // POST /api/venues
    if (pathname === '/api/venues' && method === 'POST') {
      const body = await readBody(req);
      const created = createVenue(body);
      return sendJSON(res, 201, created);
    }

    // ---------- SEO architecture: region / category / venue pages ----------
    // Registered last, after every fixed route and every /api/* route above,
    // so these broad patterns can never shadow anything that already exists.
    // Each one validates strictly against known regions/categories/slugs —
    // anything that doesn't match a real region, category, or venue falls
    // through to the plain 404 at the bottom of this function.

    // GET /:region/:category/:slug — individual venue page
    const venuePageMatch = pathname.match(/^\/([a-z-]+)\/([a-z-]+)\/([a-z0-9-]+)\/?$/);
    if (venuePageMatch && method === 'GET') {
      const [, region, categorySlug, slug] = venuePageMatch;
      const type = SLUG_TO_TYPE[categorySlug];
      if (REGION_LABELS[region] && type) {
        const venue = findVenueBySlug(region, type, slug);
        if (venue) {
          // Phase 2.8D: duplicate-retirement redirect check. Resolve at
          // most ONE hop -- if the canonical target is missing, or is
          // itself redirected (a chain), fail OPEN by rendering this
          // venue's own page normally rather than producing a broken or
          // chained redirect. A dangling/chained redirect_to is a data
          // problem to be fixed at the source, never resolved at request
          // time by following multiple hops.
          if (venue.redirect_to) {
            const canonical = getVenue(venue.redirect_to);
            if (canonical && !canonical.redirect_to && CATEGORY_SLUGS[canonical.type] && canonical.slug) {
              const target = `/${canonical.region}/${CATEGORY_SLUGS[canonical.type]}/${canonical.slug}${parsed.search || ''}`;
              res.writeHead(301, { Location: target });
              return res.end();
            }
            console.error(`[redirect] venue ${venue.id} has redirect_to=${venue.redirect_to} but the target is missing/chained/invalid -- rendering venue ${venue.id} normally instead of redirecting.`);
          }
          const relatedVenues = getRelatedVenues(venue);
          const nearbyVenues = getNearbyVenues(venue);
          const venueGuidePages = listGuideCombos(MIN_GUIDE_VENUES).filter((c) => c.region === region && venue[c.badge]);
          const html = renderVenuePage(venue, relatedVenues, nearbyVenues, venueGuidePages);
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          return res.end(html);
        }
      }
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(render404Page(pathname));
    }

    // GET /:region/:category — category page within a region
    const categoryPageMatch = pathname.match(/^\/([a-z-]+)\/([a-z-]+)\/?$/);
    if (categoryPageMatch && method === 'GET') {
      const [, region, categorySlug] = categoryPageMatch;
      const type = SLUG_TO_TYPE[categorySlug];
      if (REGION_LABELS[region] && type) {
        const venues = getVenuesByRegionCategory(region, type);
        if (venues.length >= MIN_CATEGORY_VENUES) {
          const categoryGuidePages = listGuideCombos(MIN_GUIDE_VENUES).filter(
            (c) => c.region === region && venues.some((v) => v[c.badge])
          );
          const html = renderCategoryPage(region, type, venues, categoryGuidePages);
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          return res.end(html);
        }
      }
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(render404Page(pathname));
    }

    // GET /:region — region hub page
    const regionPageMatch = pathname.match(/^\/([a-z-]+)\/?$/);
    if (regionPageMatch && method === 'GET') {
      const [, region] = regionPageMatch;
      if (REGION_LABELS[region]) {
        const categoryCounts = getRegionCategoryCounts(region);
        if (Object.keys(categoryCounts).length > 0) {
          const regionGuidePages = listGuideCombos(MIN_GUIDE_VENUES).filter((c) => c.region === region);
          const html = renderRegionPage(region, categoryCounts, regionGuidePages);
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          return res.end(html);
        }
      }
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(render404Page(pathname));
    }

    return sendJSON(res, 404, { error: 'Not found' });

  } catch (err) {
    const status = err.status || 500;
    return sendJSON(res, status, { error: err.message });
  }
});

function startServer() {
  server.listen(PORT, () => {
    console.log(`Okanagan Roam API listening on http://localhost:${PORT}`);

    // Slug backfill runs AFTER the server is already listening and serving
    // every existing route (homepage, /api/*, /guide/*, etc.) — deliberately
    // not at module-load time. This way, if this step ever fails for an
    // unexpected reason, the site stays up and continues serving everything
    // it already could; only the not-yet-slugged venues' new pages would be
    // affected, never the whole site. The migration/schema setup in db.js
    // (adding columns, fixing the index) still runs at module-load — that
    // part is purely additive/idempotent and has been safe in every test.
    try {
      const { count, errors } = backfillSlugs();
      if (count > 0) {
        console.log(`[seo] backfilled slugs for ${count} venue(s)`);
      }
      if (errors.length > 0) {
        console.error(`[seo] WARNING: ${errors.length} venue(s) could NOT be given a unique slug:`);
        for (const e of errors) {
          console.error(`[seo]   id=${e.id} name="${e.name}" region=${e.region} type=${e.type} — ${e.reason}`);
        }
      }
    } catch (err) {
      console.error('[seo] slug backfill failed unexpectedly (site remains up):', err);
    }
  });
}

// Phase 5 Sprint 1 — testability guard. `require.main === module` is true
// only when this file is the one actually launched (`node server.js`,
// exactly how Railway/`npm start` run it today via package.json's
// "start" script) — so production behavior is byte-for-byte unchanged.
// When a test file instead does `require('../server.js')`, require.main
// is the test runner, not this file, so the guard is false and the real
// HTTP listener never starts — letting tests exercise the exported pure
// functions below in-process without binding a port or affecting a
// running instance.
if (require.main === module) {
  startServer();
}

// Exported for the Phase 5 Sprint 1 test foundation (tests/*.test.js).
// Every exported item is a pure function or a function whose only
// side effect is reading the already-open `db` connection — nothing here
// starts the server or opens a second database connection. Kept
// deliberately narrow: only what the test foundation in Section 14 of the
// Sprint 1 brief actually calls for (routes, slugs, JSON-LD, sitemap,
// database reads), not a blanket re-export of the whole module.
module.exports = {
  startServer,
  server,
  slugify,
  escapeHtml,
  breadcrumbListSchema,
  buildOpeningHoursSpecification,
  badgeChipsHtml,
  breadcrumbNavHtml,
  venueCardHtml,
  listVenues,
  getVenue,
  getVenuesByRegionCategory,
  findVenueBySlug,
  getRelatedVenues,
  getNearbyVenues,
  getRegionCategoryCounts,
  listGuideCombos,
  getStats,
  renderVenuePage,
  renderCategoryPage,
  renderRegionPage,
  renderGuidePage,
  render404Page,
  CATEGORY_SLUGS,
  REGION_LABELS,
  MIN_GUIDE_VENUES,
  MIN_CATEGORY_VENUES,
};
